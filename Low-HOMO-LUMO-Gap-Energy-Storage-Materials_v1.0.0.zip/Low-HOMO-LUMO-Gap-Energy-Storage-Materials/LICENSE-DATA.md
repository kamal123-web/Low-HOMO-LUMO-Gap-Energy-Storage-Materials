# Licence for data and documents

The data files in `data/`, `results/` and `si/` and the documents in `docs/` are licensed under the
Creative Commons Attribution 4.0 International licence (CC BY 4.0):
https://creativecommons.org/licenses/by/4.0/legalcode

You may share and adapt them for any purpose, including commercially, provided you give appropriate credit
(cite the paper and the Zenodo archive; see `CITATION.cff`). The source code in `src/`, `analysis/`, `tests/`
and the notebook is licensed under the MIT licence (`LICENSE`).

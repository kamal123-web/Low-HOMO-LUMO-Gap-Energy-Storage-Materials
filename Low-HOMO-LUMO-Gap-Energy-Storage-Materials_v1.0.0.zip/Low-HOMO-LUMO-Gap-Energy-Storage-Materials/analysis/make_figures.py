import json,numpy as np,matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from rdkit import Chem
from rdkit.Chem import rdFingerprintGenerator as G
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold,cross_val_predict
from sklearn.metrics import r2_score,mean_absolute_error as mae
R=sorted([json.loads(l) for l in open('results/All_results.jsonl') if l.strip()],key=lambda r:r['Molecule_ID'])
y=np.array([r['HOMO_LUMO_Gap_eV'] for r in R]); sf=np.array([r['Molecule_ID'] in('MOL_0007','MOL_0035') for r in R])
BL,RD='#4A8FD6','#D9685E'
plt.rcParams.update({'font.size':13,'axes.edgecolor':'#bbb','axes.linewidth':1.5})
fig,ax=plt.subplots(figsize=(10,6.9)); bins=np.linspace(2.8,7.8,21)
ax.hist(y[~sf],bins=bins,color=BL,edgecolor='k',lw=1.2,label=f'Standard scaffolds (N={(~sf).sum()}, B3LYP/STO-3G)')
ax.hist(y[sf],bins=bins,color=RD,edgecolor='k',lw=1.2,label=f'Hypervalent –SF₅ derivatives (N={sf.sum()}, B3LYP/6-31G(d))')
ax.set_xlabel('Calculated HOMO–LUMO gap (eV)',fontweight='bold'); ax.set_ylabel('Number of molecules',fontweight='bold')
ax.set_ylim(0,12); ax.grid(axis='y',ls=':',alpha=.6); ax.legend(frameon=False,loc='upper left',fontsize=11); ax.set_axisbelow(True)
fig.tight_layout(); fig.savefig('analysis/fig5.png',dpi=300); plt.close()
gen=G.GetMorganGenerator(radius=2,fpSize=2048)
X=np.array([gen.GetCountFingerprintAsNumPy(Chem.MolFromSmiles(r['SMILES'])) for r in R],float)
p=cross_val_predict(Ridge(alpha=0.1),X,y,cv=KFold(5,shuffle=True,random_state=42))
r2,e=r2_score(y,p),mae(y,p); print(r2,e)
fig,ax=plt.subplots(figsize=(8,7.3)); lo,hi=2.6,8.0
ax.plot([lo,hi],[lo,hi],'--',color='#C0444F',lw=2,label='Identity (y = x)')
ax.scatter(y[~sf],p[~sf],s=110,c=BL,edgecolor='k',lw=1.3,label='Out-of-fold predictions',zorder=3)
ax.scatter(y[sf],p[sf],s=110,c=RD,edgecolor='k',lw=1.3,label='–SF₅ molecules',zorder=3)
ax.text(0.03,0.97,f'Ridge regression, α = 0.1\nN = 50, 5-fold cross-validation\nCV R² = {r2:.4f}\nCV MAE = {e:.4f} eV',transform=ax.transAxes,va='top',fontsize=12,bbox=dict(boxstyle='round',fc='#f0f0f0',ec='gray'))
ax.set_xlim(lo,hi);ax.set_ylim(lo,hi);ax.set_xlabel('DFT HOMO–LUMO gap (eV)',fontweight='bold');ax.set_ylabel('Predicted gap, Ridge regression (eV)',fontweight='bold')
ax.grid(ls=':',alpha=.6); ax.legend(loc='lower right',frameon=False); fig.tight_layout(); fig.savefig('analysis/fig6.png',dpi=300)

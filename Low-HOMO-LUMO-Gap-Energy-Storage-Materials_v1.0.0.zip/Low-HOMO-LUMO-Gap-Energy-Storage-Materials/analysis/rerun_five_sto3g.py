#!/usr/bin/env python3
"""
rerun_five_sto3g.py
-------------------
Recomputes the electronic structure of the five REPAIRED *standard* molecules
(MOL_0020, MOL_0021, MOL_0037, MOL_0048, MOL_0049) at B3LYP/STO-3G, as the
manuscript states, instead of the 6-31G(d) that the driver used by mistake.

Geometry used: research_data/<ID>_perfect_geometry.xyz  (the repaired geometry
that the G3 engine wrote and that the old 6-31G(d) value was computed on).
No re-optimisation is done, so the geometry is identical to the original run.

USAGE (Colab or local, from the folder that contains research_data/):
    pip install pyscf ase numpy
    python rerun_five_sto3g.py                     # STO-3G recompute
    python rerun_five_sto3g.py --verify            # also re-run 6-31G(d) and
                                                   # compare with the old energy
    python rerun_five_sto3g.py --results research_data/results.jsonl \
                               --datadir research_data --out All_results_corrected.jsonl
In a notebook cell:  %run rerun_five_sto3g.py --verify

OUTPUT: All_results_corrected.jsonl  (original is never modified) and
        rerun_five_sto3g_log.csv     (old vs new numbers).
"""
import argparse, json, os, sys, time, csv
import numpy as np
from pyscf import gto, dft, scf

HARTREE_TO_EV = 27.211386245988
TARGETS = ["MOL_0020", "MOL_0021", "MOL_0037", "MOL_0048", "MOL_0049"]
XC = "b3lyp"


def read_xyz(path):
    """Tolerant reader: plain XYZ or extxyz; takes first 4 columns of atom rows."""
    with open(path, encoding="utf-8") as fh:
        lines = [l.rstrip("\n") for l in fh]
    n = int(lines[0].split()[0])
    syms, xyz = [], []
    for l in lines[2:2 + n]:
        p = l.split()
        syms.append(p[0].capitalize())
        xyz.append([float(p[1]), float(p[2]), float(p[3])])
    if len(syms) != n:
        raise ValueError(f"{path}: expected {n} atoms, got {len(syms)}")
    return syms, np.array(xyz)


def single_point(syms, xyz, basis):
    atom = "; ".join(f"{s} {x:.8f} {y:.8f} {z:.8f}" for s, (x, y, z) in zip(syms, xyz))
    mol = gto.M(atom=atom, basis=basis, charge=0, spin=0, verbose=0, max_memory=2000)
    # RHF seed -> B3LYP (robust convergence), then Newton fallback
    rhf = scf.RHF(mol); rhf.max_cycle = 200; rhf.kernel()
    mf = dft.RKS(mol); mf.xc = XC
    mf.max_cycle = 250; mf.conv_tol = 1e-7
    mf.kernel(dm0=rhf.make_rdm1())
    if not mf.converged:
        mf.level_shift = 0.4; mf.damp = 0.5
        mf.kernel()
    if not mf.converged:
        mf = scf.newton(mf); mf.max_cycle = 100; mf.kernel()
    if not mf.converged:
        raise RuntimeError("SCF did not converge")
    e = np.sort(np.asarray(mf.mo_energy))
    nocc = mol.nelectron // 2
    homo, lumo = e[nocc - 1] * HARTREE_TO_EV, e[nocc] * HARTREE_TO_EV
    return dict(E=float(mf.e_tot), homo=float(homo), lumo=float(lumo),
                gap=float(lumo - homo), conv=bool(mf.converged), nbf=mol.nao)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--results", default=None, help="results.jsonl (default: research_data/results.jsonl or All_results.jsonl)")
    ap.add_argument("--datadir", default="research_data")
    ap.add_argument("--out", default="All_results_corrected.jsonl")
    ap.add_argument("--verify", action="store_true",
                    help="also recompute at 6-31G(d) and compare to the stored energy")
    a = ap.parse_args()

    res = a.results
    if res is None:
        for c in (os.path.join(a.datadir, "results.jsonl"), "All_results.jsonl", "results.jsonl"):
            if os.path.exists(c):
                res = c; break
    if res is None or not os.path.exists(res):
        sys.exit("Cannot find the results .jsonl - pass --results PATH")
    print("Reading", res)

    recs = []
    with open(res, encoding="utf-8") as fh:
        for l in fh:
            if l.strip():
                recs.append(json.loads(l))

    log = []
    for r in recs:
        mid = r.get("Molecule_ID")
        if mid not in TARGETS:
            continue
        path = os.path.join(a.datadir, f"{mid}_perfect_geometry.xyz")
        if not os.path.exists(path):
            sys.exit(f"Missing {path}. Keep all MOL_*_perfect_geometry.xyz in {a.datadir}/")
        syms, xyz = read_xyz(path)
        old = (r["Total_Electronic_Energy_Hartree"], r["HOMO_eV"], r["LUMO_eV"], r["HOMO_LUMO_Gap_eV"])
        t0 = time.time()
        print(f"\n[{mid}] {r['SMILES']}  ({len(syms)} atoms)", flush=True)

        if a.verify:
            v = single_point(syms, xyz, "6-31g(d)")
            print(f"   verify 6-31G(d): E={v['E']:.8f} (stored {old[0]:.8f}), diff={v['E']-old[0]:+.2e} Ha")
            if abs(v["E"] - old[0]) > 1e-4:
                print("   WARNING: perfect_geometry.xyz is not the geometry behind the stored value!")

        n = single_point(syms, xyz, "sto-3g")
        print(f"   STO-3G : E={n['E']:.8f} Ha  HOMO={n['homo']:.4f}  LUMO={n['lumo']:.4f}  gap={n['gap']:.4f} eV "
              f"({n['nbf']} basis functions, {time.time()-t0:.0f}s)")
        log.append([mid, r["SMILES"], *old, n["E"], n["homo"], n["lumo"], n["gap"]])

        r["Total_Electronic_Energy_Hartree"] = n["E"]
        r["HOMO_eV"] = n["homo"]
        r["LUMO_eV"] = n["lumo"]
        r["HOMO_LUMO_Gap_eV"] = n["gap"]
        r["SCF_Converged"] = n["conv"]
        r["Method"] = "ETKDGv3+LBFGS (sto-3g) + G3-Repair-Engine; B3LYP/STO-3G single point on repaired geometry"
        r["Basis_Electronic"] = "sto-3g"
        r["Correction_Note"] = "Recomputed at STO-3G (previous value was B3LYP/6-31G(d))"

    done = {x[0] for x in log}
    missing = [t for t in TARGETS if t not in done]
    if missing:
        print("WARNING: not found in results file:", missing)

    with open(a.out, "w", encoding="utf-8") as fh:
        for r in recs:
            fh.write(json.dumps(r) + "\n")
    with open("rerun_five_sto3g_log.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["ID", "SMILES", "E_old_Ha", "HOMO_old", "LUMO_old", "gap_old",
                    "E_new_Ha", "HOMO_new", "LUMO_new", "gap_new"])
        w.writerows(log)
    print(f"\nDone. Wrote {a.out} ({len(recs)} records) and rerun_five_sto3g_log.csv")
    print("Original file untouched. Send me both new files.")


if __name__ == "__main__":
    main()

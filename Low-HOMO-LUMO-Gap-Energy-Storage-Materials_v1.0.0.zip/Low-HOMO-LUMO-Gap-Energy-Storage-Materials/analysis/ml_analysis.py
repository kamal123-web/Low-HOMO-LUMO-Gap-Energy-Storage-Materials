import json,sys,numpy as np
from rdkit import Chem
from rdkit.Chem import rdFingerprintGenerator as G
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import KFold,GroupKFold,cross_val_predict
from sklearn.metrics import r2_score,mean_absolute_error as mae
f=sys.argv[1] if len(sys.argv)>1 else 'results/All_results.jsonl'
R=[json.loads(l) for l in open(f) if l.strip()]
R.sort(key=lambda r:r['Molecule_ID'])
gen=G.GetMorganGenerator(radius=2,fpSize=2048)
X=np.array([gen.GetCountFingerprintAsNumPy(Chem.MolFromSmiles(r['SMILES'])) for r in R],float)
y=np.array([r['HOMO_LUMO_Gap_eV'] for r in R])
ids=[int(r['Molecule_ID'][4:]) for r in R]
core=np.array([0 if i<=28 else 1 for i in ids])
sub=[]
nap=['F','Cl','Br','I','CN','CF3','SF5','OCF3','SCF3','CH3','CCH','NH2','OH','OMe','SMe','Ac','COOH','COOMe','CONH2','SO2Me','NHSO2Me','NMe2']
ben=nap[:19]+['SO2Me','NHSO2Me','NMe2','CH2F','CHF2','OVinyl','CH2CH2NH2','CH2OH','SH']
# benzene ids1-28 : 1-19 same,20 SO2Me 21 NHSO2Me 22 NMe2 23.. extras; naph 29-47 same as nap[:19], 48 SO2Me,49 NHSO2Me,50 NMe2
for i in ids:
    sub.append(ben[i-1] if i<=28 else nap[i-29])
print(len(set(sub)))
kf=KFold(5,shuffle=True,random_state=42)
def ev(m,Xs,ys,cv=kf,groups=None):
    p=cross_val_predict(m,Xs,ys,cv=cv,groups=groups); return r2_score(ys,p),mae(ys,p),p
for a in [0.1,0.3,1,3,10,30,100]:
    m=Ridge(alpha=a).fit(X,y); p=m.predict(X)
    r,e,_=ev(Ridge(alpha=a),X,y); print('ridge',a,round(r2_score(y,p),5),round(mae(y,p),4),round(r,4),round(e,4))
r,e,p=ev(Ridge(alpha=0.1),X,y); print('REPORTED',r,e)
err=np.abs(p-y); o=np.argsort(-err)[:5]
for k in o: print(R[k]['Molecule_ID'],round(err[k],3),round(y[k],2),round(p[k],2))
for k in range(len(R)):
    if R[k]['Molecule_ID'] in('MOL_0007','MOL_0035'): print('SF5',R[k]['Molecule_ID'],round(err[k],3))
res=[]
for d in [2,3,4,5,6,None]:
  for l in [1,2,3,4,5]:
    m=RandomForestRegressor(100,max_depth=d,min_samples_leaf=l,random_state=42)
    r,e,_=ev(m,X,y); m.fit(X,y); pt=m.predict(X)
    res.append((r,e,d,l,r2_score(y,pt),mae(y,pt)))
res.sort(key=lambda t:-t[0])
for t in res[:10]: print('rf',t[2],t[3],round(t[4],4),round(t[5],4),round(t[0],4),round(t[1],4))
# core mean baseline CV
p=np.zeros(len(y))
for tr,te in kf.split(X):
    for c in (0,1): p[te[core[te]==c]]=y[tr][core[tr]==c].mean()
print('coremean',r2_score(y,p),mae(y,p))
# grouped
codes=np.array([sorted(set(sub)).index(s) for s in sub])
gk=GroupKFold(5)
pg=cross_val_predict(Ridge(alpha=0.1),X,y,cv=gk,groups=codes); print('grouped ridge',r2_score(y,pg),mae(y,pg))
pc=np.zeros(len(y))
for tr,te in gk.split(X,y,codes):
    for c in (0,1): pc[te[core[te]==c]]=y[tr][core[tr]==c].mean()
print('grouped coremean',r2_score(y,pc),mae(y,pc))
for c,nm in((0,'benz'),(1,'naph')):
    mk=core==c; r,e,_=ev(Ridge(alpha=0.1),X[mk],y[mk],KFold(5,shuffle=True,random_state=42)); print(nm,mk.sum(),r,e)
print('std range',y[[i not in(7,35) for i in ids]].min(),y.max())
print('--- repeated grouped 5-fold (100 random group partitions)')
rs=[];ms=[];cr=[]
for seed in range(100):
    rng=np.random.RandomState(seed); g2=rng.permutation(len(set(sub)))[codes]
    pg=cross_val_predict(Ridge(alpha=0.1),X,y,cv=GroupKFold(5),groups=g2); rs.append(r2_score(y,pg)); ms.append(mae(y,pg))
    pc=np.zeros(len(y))
    for tr,te in GroupKFold(5).split(X,y,g2):
        for c in (0,1): pc[te[core[te]==c]]=y[tr][core[tr]==c].mean()
    cr.append(r2_score(y,pc))
print('ridge grouped mean R2',np.mean(rs),'sd',np.std(rs),'MAE',np.mean(ms),'core-mean grouped R2',np.mean(cr))
pl=cross_val_predict(Ridge(alpha=0.1),X,y,cv=LeaveOneGroupOut(),groups=codes)
pc=np.zeros(len(y))
for tr,te in LeaveOneGroupOut().split(X,y,codes):
    for c in (0,1): pc[te[core[te]==c]]=y[tr][core[tr]==c].mean()
print('LOSO ridge',r2_score(y,pl),mae(y,pl),'core-mean',r2_score(y,pc),mae(y,pc))

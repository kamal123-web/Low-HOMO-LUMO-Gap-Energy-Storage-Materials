# SI-5_reproduce.py: needs engine.py = notebook cell 20 saved as a file, and the two *_final_accepted_geometry.xyz files from cells 22-23.
# Step 1: repair
import sys; sys.path.insert(0,'.')
import engine as G
for mid,smi in (('MOL_0007','FS(F)(F)(F)(F)c1ccccc1'),('MOL_0035','FS(F)(F)(F)(F)c1cccc2ccccc12')):
    try:
        G.repair_structure(smiles=smi,input_xyz=f'{mid}_final_accepted_geometry.xyz',output_xyz=f'{mid}_perfect_geometry.xyz',output_sdf=f'{mid}_perfect.sdf',output_png=f'{mid}_2d.png',output_report=f'{mid}_validation_report.txt')
    except Exception as e:
        import traceback;traceback.print_exc()

# Step 2: before/after validation tables (writes si5.json)
import sys;sys.path.insert(0,'.')
import numpy as np, engine as G, json
from rdkit import Chem
out={}
for mid,smi in (('MOL_0007','FS(F)(F)(F)(F)c1ccccc1'),('MOL_0035','FS(F)(F)(F)(F)c1cccc2ccccc12')):
    c,sym,xyz,ex=G.parse_extended_xyz(f'{mid}_final_accepted_geometry.xyz'); xyz=np.array(xyz,float)
    mol=Chem.AddHs(G.build_reference_molecule(smi))
    m=G.map_xyz_to_smiles_robust(mol,sym,xyz); before=np.asarray(G.reorder_array(xyz,m),float)
    c2,sym2,after,ex2=G.parse_extended_xyz(f'{mid}_perfect_geometry.xyz'); after=np.array(after,float)
    assert [a.GetSymbol() for a in mol.GetAtoms()]==list(sym2)
    vb=G.validate(mol,before); va=G.validate(mol,after)
    rows=[]
    for b,a in zip(vb['report'],va['report']):
        i,j=b['i'],b['j']
        typ='S–F' if {b['ei'],b['ej']}=={'S','F'} else 'S–C' if {b['ei'],b['ej']}=={'S','C'} else 'C–H' if 'H' in (b['ei'],b['ej']) else 'C–C (aromatic)'
        rows.append(dict(i=i,j=j,atoms=f"{b['ei']}{i}–{b['ej']}{j}",type=typ,target=b['target'],before=b['distance'],after=a['distance'],ok_b=G.bond_is_good(b),ok_a=G.bond_is_good(a)))
    S=[k for k,s in enumerate(sym2) if s=='S'][0]
    def ang(P,a,b,c_):
        v1=P[a]-P[b];v2=P[c_]-P[b];return float(np.degrees(np.arccos(np.clip(np.dot(v1,v2)/np.linalg.norm(v1)/np.linalg.norm(v2),-1,1))))
    nb=[a.GetIdx() for a in mol.GetAtomWithIdx(S).GetNeighbors()]
    fl=[k for k in nb if sym2[k]=='F'];C=[k for k in nb if sym2[k]=='C'][0]
    angs=lambda P:{ 'C-S-F':sorted(round(ang(P,C,S,f),1) for f in fl),'F-S-F':sorted(round(ang(P,f1,S,f2),1) for n,f1 in enumerate(fl) for f2 in fl[n+1:]) }
    out[mid]=dict(smiles=smi,rows=rows,
      nb=len(vb['bad']),na=len(va['bad']),cb=len(vb['clashes']),ca=len(va['clashes']),
      maxb=vb['max_error'],maxa=va['max_error'],meanb=vb['mean_error'],meana=va['mean_error'],
      angb=angs(before),anga=angs(after),
      clashes_b=[(mol.GetAtomWithIdx(x['i']).GetSymbol()+str(x['i']),mol.GetAtomWithIdx(x['j']).GetSymbol()+str(x['j']),round(float(x['distance']),2)) for x in vb['clashes']] if vb['clashes'] and 'distance' in vb['clashes'][0] else str(vb['clashes'][:3]))
    print(mid,out[mid]['nb'],out[mid]['na'],out[mid]['cb'],out[mid]['ca'],round(out[mid]['maxb'],3),round(out[mid]['maxa'],3),out[mid]['angb'],out[mid]['anga'])
    print(' clashes before sample',str(vb['clashes'][:2])[:200])
json.dump(out,open('si5.json','w'))

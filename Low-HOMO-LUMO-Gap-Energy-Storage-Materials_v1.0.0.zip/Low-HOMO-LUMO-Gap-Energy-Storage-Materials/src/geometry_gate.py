#!/usr/bin/env python3
"""
geometry_gate.py  -  mandatory validation gate for the screening driver
=======================================================================
Put next to g3_engine.py, geom_common.py and validate_geometry.py.

WHY: the old driver only ran G1 when a SMARTS list said "hypervalent".  A
molecule that is not in that list (e.g. O=I(O)(O)Ph, I(V)) was never
validated at all.  This gate runs on EVERY molecule:

    optimizer geometry --> validate --PASS--> keep the relaxed geometry
                                     +-FAIL--> G3 rebuild --> re-validate

* Geometries that already pass are left untouched (no needless SCF re-run,
  relaxed structure preserved).
* Only failing geometries are rebuilt, whatever the element or SMILES.
* If the rebuild still fails the result is flagged GEOMETRY_INVALID instead
  of being reported as a success.

Tolerances are deliberately looser than for template geometries, because the
input is a DFT/ASE-relaxed structure (bonds 0.15 A / 8 %, angles 20 deg).
They still catch the real failure modes (detached ligands at 3 A, shells
distorted by tens of degrees, collapsed cages).

Use in the driver
-----------------
    from geometry_gate import validate_and_repair
    gate = validate_and_repair(molecule_id, smiles, raw_xyz_path, OUTPUT_DIR)
    record.update(gate["record_fields"])
    if gate["action"] == "REPAIRED":
        atoms = ase_read(gate["xyz"])          # then SCF on the repaired atoms
        attach_pyscf_calculator(atoms, basis=FINAL_BASIS, xc=FINAL_XC)
        qc = run_final_electronic_qc(atoms, molecule_id)
        ...
    elif gate["status"] == "UNRESOLVED":
        record["Status"] = "GEOMETRY_INVALID"

Audit existing results (no calculations, seconds per molecule):
    python geometry_gate.py --audit research_data
"""
import argparse
import csv
import glob
import json
import os
import sys

import numpy as np
from rdkit import Chem

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geom_common as gco  # noqa: E402  (never name it "gc": that shadows the stdlib garbage-collector module)

if not hasattr(gco, "check_geometry"):
    raise ImportError(
        f"geom_common loaded from {getattr(gco, '__file__', '?')} has no "
        "check_geometry: a stale or different geom_common.py is being imported. "
        "Keep ONE copy (from the same download as geometry_gate.py), delete "
        "__pycache__, and restart the Python session / Colab runtime.")

# optimizer-output tolerances (relaxed structures, not templates)
RELAXED = dict(tol_abs=0.15, tol_rel=0.08, ang_tol=20.0, hyper_scale=1.3,
               clash_factor=0.65, plane_tol=0.08)


def _load(mol, path):
    from validate_geometry import load_in_smiles_order
    return load_in_smiles_order(mol, path)


def check_file(smiles, xyz_path, **tol):
    mol = Chem.AddHs(Chem.MolFromSmiles(smiles))
    X, note = _load(mol, xyz_path)
    return mol, X, gco.check_geometry(mol, X, **(tol or RELAXED)), note


def validate_and_repair(mol_id, smiles, raw_xyz, out_dir, force_repair=False,
                        verbose=True):
    """Validate `raw_xyz`; rebuild with G3 only if it fails.
    Returns dict(action, status, xyz, record_fields, before, after)."""
    from g3_engine import repair_structure
    from validate_geometry import write_outputs
    os.makedirs(out_dir, exist_ok=True)   # added for the archived release
    pre = os.path.join(out_dir, f"{mol_id}_geometry")
    fields = {"Geometry_Gate": "G3-validator-v2"}
    try:
        mol, X, before, note = check_file(smiles, raw_xyz)
    except Exception as exc:        # unreadable / wrong composition / unmappable
        before, note, mol, X = None, f"input could not be validated: {exc}", None, None
        if verbose:
            print(f"  -> [GATE] {note}", flush=True)

    if before is not None and before["verdict"] == "PASS" and not force_repair:
        write_outputs(pre, smiles, mol, before, None, [note])
        fields.update(Geometry_Validation="PASS", Geometry_Action="KEPT_RELAXED",
                      Geometry_Bad_Bonds_Before=0,
                      Geometry_Max_Bond_Err_A=round(before["max_err"], 4))
        if verbose:
            print("  -> [GATE] relaxed geometry valid; kept.", flush=True)
        return dict(action="KEPT", status="PASS", xyz=raw_xyz,
                    record_fields=fields, before=before, after=before)

    if verbose and before is not None:
        print("  -> [GATE] geometry INVALID: " + "; ".join(before["reasons"]),
              flush=True)
    perfect = os.path.join(out_dir, f"{mol_id}_perfect_geometry.xyz")
    repair_structure(
        smiles, raw_xyz if before is not None else None, perfect,
        os.path.join(out_dir, f"{mol_id}_perfect.sdf"),
        os.path.join(out_dir, f"{mol_id}_2d_projection.png"),
        os.path.join(out_dir, f"{mol_id}_validation_report.txt"))
    # re-validate the written file with the strict (template) tolerances
    mol2, X2, after, note2 = check_file(smiles, perfect, **dict(
        tol_abs=0.10, tol_rel=0.06, ang_tol=15.0, hyper_scale=1.0,
        clash_factor=0.65, plane_tol=0.06))
    ok = after["verdict"] == "PASS"
    if before is not None:
        write_outputs(pre, smiles, mol2, after, before, [note, note2])
        # `before` must be re-evaluated in the same (strict) frame for the report
    if before is None:
        fields["Geometry_Note"] = note[:200]
    fields.update(
        Geometry_Validation="PASS" if ok else "FAIL",
        Geometry_Action="REPAIRED" if ok else "REPAIR_FAILED",
        Geometry_Bad_Bonds_Before=len(before["bad_bonds"]) if before else None,
        Geometry_Max_Bond_Err_A=round(after["max_err"], 4))
    return dict(action="REPAIRED" if ok else "REPAIR_FAILED",
                status="PASS" if ok else "UNRESOLVED", xyz=perfect,
                record_fields=fields, before=before, after=after)


# ---------------------------------------------------------------------------
# audit of an existing research_data folder
# ---------------------------------------------------------------------------
def audit(folder, out_csv=None):
    smiles = {}
    rj = os.path.join(folder, "results.jsonl")
    if os.path.isfile(rj):
        with open(rj, encoding="utf-8") as fh:
            for ln in fh:
                try:
                    d = json.loads(ln)
                    smiles[d["Molecule_ID"]] = d["SMILES"]
                except Exception:
                    pass
    rows = []
    ids = sorted({os.path.basename(p).split("_final_accepted")[0].split("_perfect")[0]
                  for p in glob.glob(os.path.join(folder, "MOL_*_*geometry.xyz"))})
    for mid in ids:
        smi = smiles.get(mid)
        for kind in ("final_accepted", "perfect"):
            p = os.path.join(folder, f"{mid}_{kind}_geometry.xyz")
            if not os.path.isfile(p):
                continue
            if not smi:
                rows.append([mid, kind, "", "NO_SMILES", "", "", "", ""])
                continue
            try:
                _, _, c, _ = check_file(smi, p)
                rows.append([mid, kind, smi, c["verdict"], len(c["bad_bonds"]),
                             f"{c['max_err']:.3f}",
                             "; ".join(f"{h['element']} {h['geometry']} dev {h['max_dev']:.0f}"
                                       for h in c["hyper"]),
                             "; ".join(c["reasons"])])
            except Exception as exc:
                rows.append([mid, kind, smi, "ERROR", "", "", "", str(exc)[:80]])
    out_csv = out_csv or os.path.join(folder, "geometry_audit.csv")
    with open(out_csv, "w", newline="") as fh:
        w = csv.writer(fh)
        w.writerow(["Molecule_ID", "file", "SMILES", "verdict", "bad_bonds",
                    "max_bond_err_A", "hypervalent_shells", "issues"])
        w.writerows(rows)
    for r in rows:
        print(f"{r[0]:9s} {r[1]:15s} {r[3]:6s} bad={r[4]} max={r[5]} {r[6]} {r[7]}")
    print("written:", out_csv)
    return rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--audit", help="folder with MOL_*_*_geometry.xyz + results.jsonl")
    a = ap.parse_args()
    if a.audit:
        audit(a.audit)
    else:
        ap.print_help()

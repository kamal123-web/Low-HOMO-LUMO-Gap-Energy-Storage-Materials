#!/usr/bin/env python3
"""
validate_geometry.py  v2  -  SMILES-authoritative geometry validator
====================================================================
Works for ordinary AND hypervalent / heavy-element molecules (S(VI), P(V),
I(III), I(V), Xe, ...).  All checks come from geom_common.check_geometry():

  1. composition + atom order (AddHs(SMILES) order; auto-remap if needed)
  2. every SMILES bond vs a context-aware target   (detached atoms are shown
     with their TRUE distance - never replaced by the "after" value)
  3. unintended contacts / detached bonds perceived from the coordinates
  4. angles at every atom (hypervalent shells matched to octahedral, TBP,
     T-shape, see-saw, linear ... by brute-force ligand->site assignment,
     so the result does not depend on how the ligands happen to be ordered)
  5. planarity of aromatic rings and sp2 centres
  6. steric clashes (graph distance >= 3, vdW based)

Usage
-----
  GUI (PyQt6 dashboard, like before):  python validate_geometry.py     (no arguments)
  command line:
  single file:
    python validate_geometry.py --smiles "FI(F)c1ccccc1" --after out.xyz
  before / after comparison:
    python validate_geometry.py --smiles "..." --before old.xyz --after new.xyz \
           --prefix MOL_0007 --plot
  batch (CSV with header  name,smiles,xyz  [,before]):
    python validate_geometry.py --batch list.csv --outdir reports

Exit code 0 = all PASS, 1 = at least one FAIL.
"""
import argparse
import csv
import json
import os
import sys

import numpy as np
from rdkit import Chem, RDLogger

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geom_common as gco  # noqa: E402  (never name it "gc": that shadows the stdlib garbage-collector module)

RDLogger.DisableLog("rdApp.*")


def read_xyz(path):
    with open(path, encoding="utf-8", errors="ignore") as fh:
        lines = fh.read().splitlines()
    n = int(lines[0].split()[0])
    sym, xyz = [], []
    for ln in lines[2:]:
        p = ln.split()
        if len(p) < 4:
            continue
        try:
            xyz.append([float(p[1]), float(p[2]), float(p[3])])
        except ValueError:
            continue
        sym.append(p[0])
    if len(sym) != n:
        raise ValueError(f"{path}: header says {n} atoms, parsed {len(sym)}")
    return sym, np.asarray(xyz, float)


def smiles_mol(smiles):
    m = Chem.MolFromSmiles(smiles)
    if m is None:
        raise ValueError(f"Invalid SMILES: {smiles}")
    return Chem.AddHs(m)


def load_in_smiles_order(mol, path):
    """Return (coords in AddHs(SMILES) order, note)."""
    sym, X = read_xyz(path)
    ref = [a.GetSymbol() for a in mol.GetAtoms()]
    if sorted(sym) != sorted(ref):
        raise ValueError(f"{os.path.basename(path)}: composition "
                         f"{sorted(sym)} does not match SMILES {sorted(ref)}")
    if sym == ref:
        return X, "atom order identical to AddHs(SMILES)"
    from g3_engine import map_input        # graph-based remap
    mp = map_input(mol, sym, X)
    if mp is None:
        raise ValueError(f"{os.path.basename(path)}: atom order differs and "
                         "no unique graph mapping exists (broken topology). "
                         "Provide the file in AddHs(SMILES) order.")
    return X[np.array(mp)], "atoms remapped to SMILES order by graph match"


def fmt_summary(tag, c):
    return (f"{tag:7s} verdict={c['verdict']:4s} bad_bonds={len(c['bad_bonds'])} "
            f"max_err={c['max_err']:.3f} A  extra_contacts={len(c['extra_bonds'])} "
            f"bad_angles={len(c['bad_angles'])} bad_shells={len(c['bad_hyper'])} "
            f"nonplanar={len(c['bad_planar'])} clashes={len(c['clashes'])}")


def write_outputs(prefix, smiles, mol, after, before=None, notes=()):
    sym = [a.GetSymbol() for a in mol.GetAtoms()]
    # ---- bonds csv
    with open(f"{prefix}_bonds.csv", "w", newline="") as fh:
        w = csv.writer(fh)
        head = ["atom_i", "atom_j", "type", "order", "target_A",
                "target_source"]
        if before:
            head += ["before_A", "before_err_A", "before_ok"]
        head += ["after_A", "after_err_A", "after_ok"]
        w.writerow(head)
        for k, r in enumerate(after["bonds"]):
            row = [f"{r['ei']}{r['i']+1}", f"{r['ej']}{r['j']+1}",
                   f"{r['ei']}-{r['ej']}", r["order"], f"{r['target']:.3f}",
                   r["source"]]
            if before:
                b = before["bonds"][k]
                row += [f"{b['dist']:.4f}", f"{b['err']:+.4f}",
                        "PASS" if b["ok"] else "FAIL"]
            row += [f"{r['dist']:.4f}", f"{r['err']:+.4f}",
                    "PASS" if r["ok"] else "FAIL"]
            w.writerow(row)
    # ---- text report
    L = []
    L.append("SMILES-AUTHORITATIVE GEOMETRY VALIDATION (validate_geometry v2)")
    L.append("=" * 78)
    L.append(f"SMILES : {smiles}")
    L.append(f"Atoms  : {mol.GetNumAtoms()}   Bonds: {mol.GetNumBonds()}")
    for n in notes:
        L.append(f"Note   : {n}")
    L.append("")
    if before:
        L.append(fmt_summary("BEFORE", before))
    L.append(fmt_summary("AFTER", after))
    if after["reasons"]:
        L.append("AFTER issues: " + "; ".join(after["reasons"]))
    L.append("")
    L.append("BOND TABLE  (* = outside tolerance; distances are the true "
             "values from each file)")
    L.append("-" * 78)
    for k, r in enumerate(after["bonds"]):
        s = (f"{r['ei']:>2s}{r['i']+1:<3d}-{r['ej']:>2s}{r['j']+1:<3d} "
             f"target {r['target']:.3f}{'f' if r['source']=='fallback' else ' '}")
        if before:
            b = before["bonds"][k]
            s += f" | before {b['dist']:7.3f}{'*' if not b['ok'] else ' '}"
        s += f" | after {r['dist']:7.3f}{'*' if not r['ok'] else ' '}"
        L.append(s)
    L.append("(f = target from covalent-radii fallback: pair not in table)")
    L.append("")
    for tag, c in (("BEFORE", before), ("AFTER", after)):
        if c is None or not c["hyper"]:
            continue
        L.append(f"HYPERVALENT SHELLS - {tag}")
        for h in c["hyper"]:
            L.append(f"  {h['element']}{h['centre']+1}: {h['geometry']:8s} "
                     f"ligand-angle range {h['min_angle']:.1f}-"
                     f"{h['max_angle']:.1f} deg, worst deviation from ideal "
                     f"{h['max_dev']:.1f} deg (tol {h['tol']:.0f}) "
                     f"{'PASS' if h['ok'] else 'FAIL'}")
        L.append("")
    for tag, c in (("BEFORE", before), ("AFTER", after)):
        if c is None:
            continue
        for key, title in (("extra_bonds", "unintended contacts"),
                           ("missing_bonds", "detached bonds"),
                           ("clashes", "clashes")):
            for r in c[key]:
                L.append(f"{tag} {title}: {r['ei']}{r['i']+1}...{r['ej']}"
                         f"{r['j']+1}  {r['dist']:.3f} A")
        for r in c["bad_angles"]:
            L.append(f"{tag} angle: {sym[r['i']]}{r['i']+1}-{r['ec']}"
                     f"{r['c']+1}-{sym[r['j']]}{r['j']+1} = {r['angle']:.1f} "
                     f"(ideal {r['ideal']:.1f})")
        for r in c["bad_planar"]:
            L.append(f"{tag} planarity: {r['kind']} {[x+1 for x in r['atoms']]}"
                     f" deviation {r['max_dev']:.3f}")
    L.append("")
    L.append(f"FINAL VERDICT (AFTER): {after['verdict']}")
    with open(f"{prefix}_report.txt", "w", encoding="utf-8") as fh:
        fh.write("\n".join(L) + "\n")
    # ---- json
    def brief(c):
        return None if c is None else dict(
            verdict=c["verdict"], max_bond_err=c["max_err"],
            mean_bond_err=c["mean_err"], rms_bond_err=c["rms_err"],
            bad_bonds=len(c["bad_bonds"]), extra_contacts=len(c["extra_bonds"]),
            bad_angles=len(c["bad_angles"]), bad_shells=len(c["bad_hyper"]),
            nonplanar=len(c["bad_planar"]), clashes=len(c["clashes"]),
            shells=[dict(centre=f"{h['element']}{h['centre']+1}",
                         geometry=h["geometry"], max_dev=h["max_dev"])
                    for h in c["hyper"]], reasons=c["reasons"])
    with open(f"{prefix}_summary.json", "w") as fh:
        json.dump(dict(smiles=smiles, before=brief(before),
                       after=brief(after)), fh, indent=2)


def plot(prefix, after, before=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    n = len(after["bonds"])
    lab = [f"{r['ei']}{r['i']+1}-{r['ej']}{r['j']+1}" for r in after["bonds"]]
    fig, ax = plt.subplots(figsize=(8, max(3, 0.22 * n + 1)))
    y = np.arange(n)
    if before:
        ax.barh(y + 0.2, [abs(b["err"]) for b in before["bonds"]], 0.4,
                label="before", color="#c0504d")
    ax.barh(y - 0.2 if before else y, [abs(r["err"]) for r in after["bonds"]],
            0.4, label="after", color="#4f81bd")
    ax.axvline(0.10, color="k", ls="--", lw=0.8)
    ax.set_yticks(y)
    ax.set_yticklabels(lab, fontsize=7)
    ax.invert_yaxis()
    ax.set_xlabel("|bond length - target| (A)   dashed = 0.10 A tolerance")
    ax.legend()
    fig.tight_layout()
    fig.savefig(f"{prefix}_deviation.png", dpi=160)
    plt.close(fig)


def run_one(smiles, after_path, before_path=None, prefix="report", do_plot=False):
    mol = smiles_mol(smiles)
    Xa, na = load_in_smiles_order(mol, after_path)
    notes = [f"AFTER file: {na}"]
    after = gco.check_geometry(mol, Xa)
    before = None
    if before_path:
        Xb, nb = load_in_smiles_order(mol, before_path)
        notes.append(f"BEFORE file: {nb}")
        before = gco.check_geometry(mol, Xb)
    write_outputs(prefix, smiles, mol, after, before, notes)
    if do_plot:
        plot(prefix, after, before)
    return before, after


def cli_main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--smiles")
    ap.add_argument("--after")
    ap.add_argument("--before")
    ap.add_argument("--prefix", default="report")
    ap.add_argument("--plot", action="store_true")
    ap.add_argument("--batch", help="CSV with columns name,smiles,xyz[,before]")
    ap.add_argument("--outdir", default=".")
    a = ap.parse_args()
    all_pass = True
    if a.batch:
        os.makedirs(a.outdir, exist_ok=True)
        rows = []
        with open(a.batch, newline="") as fh:
            for r in csv.DictReader(fh):
                try:
                    b, c = run_one(r["smiles"], r["xyz"], r.get("before") or None,
                                   os.path.join(a.outdir, r["name"]), a.plot)
                    rows.append((r["name"], c["verdict"], len(c["bad_bonds"]),
                                 c["max_err"], len(c["bad_angles"]) +
                                 len(c["bad_hyper"]), len(c["clashes"]),
                                 "; ".join(c["reasons"])))
                    all_pass &= c["verdict"] == "PASS"
                except Exception as exc:
                    rows.append((r["name"], "ERROR", "", "", "", "", str(exc)))
                    all_pass = False
        with open(os.path.join(a.outdir, "batch_summary.csv"), "w",
                  newline="") as fh:
            w = csv.writer(fh)
            w.writerow(["name", "verdict", "bad_bonds", "max_bond_err_A",
                        "bad_angles_or_shells", "clashes", "issues"])
            for r in rows:
                w.writerow([r[0], r[1], r[2],
                            f"{r[3]:.4f}" if r[3] != "" else "", r[4], r[5],
                            r[6]])
        for r in rows:
            print(f"{r[0]:28s} {r[1]:5s} {r[6]}")
    else:
        if not (a.smiles and a.after):
            ap.error("need --smiles and --after (or --batch)")
        b, c = run_one(a.smiles, a.after, a.before, a.prefix, a.plot)
        if b:
            print(fmt_summary("BEFORE", b))
        print(fmt_summary("AFTER", c))
        print("VERDICT:", c["verdict"], "|", "; ".join(c["reasons"]) or "all checks passed")
        all_pass = c["verdict"] == "PASS"
    sys.exit(0 if all_pass else 1)


# =============================================================================
# SI-5 REPORT TEXT (generic: works for any molecule / hypervalent shell)
# =============================================================================
def xyz_text(sym, X, comment=""):
    return (f"{len(sym)}\n{comment}\n" +
            "\n".join(f"{s} {p[0]:.6f} {p[1]:.6f} {p[2]:.6f}"
                      for s, p in zip(sym, X)) + "\n")


def si_report_text(smiles, mol, before, after, notes=()):
    sym = [a.GetSymbol() for a in mol.GetAtoms()]
    W = 100
    L = []
    L.append("Geometry validation report - SMILES-authoritative repair (validate_geometry v2)")
    L.append("Method: every bond of the SMILES graph is compared with a context-aware target "
             "length; a bond passes if |d - target| <= max(0.10 A, 6% of target).")
    L.append("Angles are checked at every atom; hypervalent centres (S(VI), P(V), I(III), "
             "I(V), Xe ...) are matched to octahedral / trigonal-bipyramidal / T-shaped / "
             "see-saw / linear shells by testing every ligand-to-site assignment.")
    L.append("Aromatic rings and sp2 centres are tested for planarity; non-bonded pairs "
             "(graph distance >= 3) closer than 0.65 x the sum of vdW radii are clashes.")
    L.append("'Before' distances are the true distances in the supplied file (detached atoms "
             "are never replaced by the 'after' value). Repaired hypervalent shells are "
             "template-built and are not re-relaxed on the DFT surface.")
    L.append("")
    L.append(f"SMILES: {smiles}")
    for n in notes:
        L.append(f"Note: {n}")
    L.append("")
    L.append("-" * W)
    L.append(f"{'Metric':<38} | {'Before':<24} | {'After':<24}")
    L.append("-" * W)

    def row(name, f):
        b = f(before) if before else "n/a"
        L.append(f"{name:<38} | {str(b):<24} | {str(f(after)):<24}")
    row("Bonds failing the length test", lambda c: len(c["bad_bonds"]))
    row("Maximum bond-length error (A)", lambda c: f"{c['max_err']:.3f}")
    row("Mean bond-length error (A)", lambda c: f"{c['mean_err']:.3f}")
    row("Unintended contacts", lambda c: len(c["extra_bonds"]))
    row("Detached bonds", lambda c: len(c["missing_bonds"]))
    row("Angles outside tolerance", lambda c: len(c["bad_angles"]))
    row("Hypervalent shells distorted", lambda c: f"{len(c['bad_hyper'])} of {len(c['hyper'])}")
    row("Planarity violations", lambda c: len(c["bad_planar"]))
    row("Steric clashes", lambda c: len(c["clashes"]))
    row("Verdict", lambda c: c["verdict"])
    L.append("-" * W)
    L.append("")
    shells = [(t, c) for t, c in (("Before", before), ("After", after)) if c]
    if any(c["hyper"] for _, c in shells):
        L.append("Hypervalent shells")
        L.append(f"{'State':<8} | {'Centre':<8} | {'Shape':<9} | {'Ligand angle range (deg)':<26} | {'Worst dev (deg)':<16} | Status")
        for t, c in shells:
            for h in c["hyper"]:
                L.append(f"{t:<8} | {h['element']+str(h['centre']+1):<8} | {h['geometry']:<9} | "
                         f"{('%.1f - %.1f' % (h['min_angle'], h['max_angle'])):<26} | "
                         f"{h['max_dev']:<16.1f} | {'PASS' if h['ok'] else 'FAIL'}")
        L.append("")
    L.append("Table SI-5. Bond-by-bond validation (distances and targets in A; |D| = absolute deviation).")
    L.append(f"{'#':<4} | {'Bond':<10} | {'Type':<8} | {'Target':<7} | {'Before':<8} | {'After':<8} | {'|D| bef':<8} | {'|D| aft':<8} | {'Bef':<5} | Aft")
    L.append("-" * W)
    for k, r in enumerate(after["bonds"]):
        b = before["bonds"][k] if before else None
        L.append(f"{k:<4} | {sym[r['i']]+str(r['i']+1)+'-'+sym[r['j']]+str(r['j']+1):<10} | "
                 f"{r['ei']+'-'+r['ej']:<8} | {r['target']:<7.3f} | "
                 f"{(('%.3f' % b['dist']) if b else 'n/a'):<8} | {r['dist']:<8.3f} | "
                 f"{(('%.3f' % abs(b['err'])) if b else 'n/a'):<8} | {abs(r['err']):<8.3f} | "
                 f"{('PASS' if b['ok'] else 'FAIL') if b else 'n/a':<5} | {'PASS' if r['ok'] else 'FAIL'}")
    L.append("")
    L.append("Notes")
    L.append("- Targets marked as covalent-radii fallback in the CSV are pairs missing from the target table; check them manually.")
    L.append("- Reproduce: run g3_engine.repair_structure(smiles, ...) then validate_geometry.py on the output.")
    return "\n".join(L) + "\n"


# =============================================================================
# DESKTOP GUI (PyQt6)  -  started when the script is run without arguments
# =============================================================================
CPK = {"H": "#ffffff", "C": "#909090", "N": "#3050f8", "O": "#ff0d0d",
       "F": "#90e050", "Cl": "#1ff01f", "Br": "#a62929", "I": "#940094",
       "S": "#ffff30", "P": "#ff8000", "Xe": "#429eb0", "Si": "#f0c8a0"}


def angle_labels(mol, X, all_atoms=False):
    """[(text, (x, y, z))] angle labels placed on the bisector near each vertex.
    Default: only hypervalent centres and angles that fail the check."""
    hyper = set(gco.hyper_centres(mol))
    out = []
    for a in mol.GetAtoms():
        c = a.GetIdx()
        nb = [n.GetIdx() for n in a.GetNeighbors()]
        if len(nb) < 2 or (not all_atoms and c not in hyper):
            continue
        for p in range(len(nb)):
            for q in range(p + 1, len(nb)):
                u, v = X[nb[p]] - X[c], X[nb[q]] - X[c]
                ang = gco._angle(X[nb[p]], X[c], X[nb[q]])
                m = u / np.linalg.norm(u) + v / np.linalg.norm(v)
                if np.linalg.norm(m) < 1e-3:                     # ~180 deg
                    m = np.cross(u, [0.3, 0.5, 0.8])
                m = m / (np.linalg.norm(m) + 1e-12)
                out.append((f"{ang:.1f}", tuple(float(t) for t in X[c] + 0.8 * m)))
    return out


def viewer_html(sym, X, bad_pairs, labels):
    data = xyz_text(sym, X)
    js_lines = "".join(
        f'viewer.addLine({{start:{{x:{X[i][0]},y:{X[i][1]},z:{X[i][2]}}},'
        f'end:{{x:{X[j][0]},y:{X[j][1]},z:{X[j][2]}}},color:"red",dashed:true,'
        f'dashLength:0.25,gapLength:0.15}});\n' for i, j in bad_pairs)
    js_lab = "".join(
        f'viewer.addLabel("{t}",{{position:{{x:{p[0]},y:{p[1]},z:{p[2]}}},'
        f'backgroundColor:"black",backgroundOpacity:0.6,fontColor:"white",'
        f'fontSize:10,borderColor:"gray"}});\n' for t, p in labels)
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8">
<script src="https://3dmol.org/build/3Dmol-min.js"></script>
<style>html,body{{margin:0;padding:0;width:100%;height:100%;overflow:hidden;background:#1e1e1e}}
#viewer{{width:100%;height:100%}}</style></head><body><div id="viewer"></div>
<script>window.addEventListener("load",function(){{
 let data={json.dumps(data)};
 let viewer=$3Dmol.createViewer(document.getElementById("viewer"),{{backgroundColor:"#1e1e1e"}});
 viewer.addModel(data,"xyz");
 viewer.setStyle({{}},{{stick:{{radius:0.17,colorscheme:"Jmol"}},sphere:{{scale:0.22,colorscheme:"Jmol"}}}});
 {js_lines}{js_lab}
 viewer.zoomTo();viewer.render();
 setTimeout(function(){{viewer.resize();viewer.zoomTo();viewer.render();}},250);}});
</script></body></html>"""


def launch_gui():
    from PyQt6.QtCore import Qt
    from PyQt6.QtGui import QColor, QBrush
    from PyQt6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
        QPushButton, QLabel, QFileDialog, QTableWidget, QTableWidgetItem,
        QSplitter, QHeaderView, QGroupBox, QMessageBox, QTabWidget, QLineEdit,
        QCheckBox, QStackedWidget)
    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    try:
        if os.environ.get("VG_NO_WEBENGINE") == "1":
            raise ImportError
        from PyQt6.QtWebEngineWidgets import QWebEngineView
        HAVE_WEB = True
    except Exception:
        HAVE_WEB = False

    GOOD, BAD = QColor("#14532d"), QColor("#7f1d1d")

    class ChartCanvas(FigureCanvas):
        def __init__(self):
            self.fig = Figure(figsize=(6, 5), facecolor="#1e1e1e")
            super().__init__(self.fig)
            self.ax1 = self.fig.add_subplot(211)
            self.ax2 = self.fig.add_subplot(212)
            self.style()

        def style(self):
            for ax in (self.ax1, self.ax2):
                ax.set_facecolor("#252526")
                ax.tick_params(colors="white", labelsize=8)
                for s in ax.spines.values():
                    s.set_color("#555555")
                ax.xaxis.label.set_color("white")
                ax.yaxis.label.set_color("white")
                ax.title.set_color("white")

        def update_plots(self, rows):
            self.ax1.clear()
            self.ax2.clear()
            self.style()
            if not rows:
                self.draw()
                return
            x = np.arange(len(rows))
            lab = [r["bond"] for r in rows]
            w = 0.35
            has_b = rows[0]["before"] is not None
            if has_b:
                self.ax1.bar(x - w / 2, [r["dev_before"] for r in rows], w,
                             label="Before", color="#ef4444")
            self.ax1.bar(x + (w / 2 if has_b else 0), [r["dev_after"] for r in rows],
                         w if has_b else 0.6, label="After", color="#10b981")
            self.ax1.axhline(0.10, color="#facc15", ls="--", lw=0.8)
            self.ax1.set_title("Absolute deviation from target |D| (dashed = 0.10 A)",
                               fontsize=10, fontweight="bold")
            self.ax1.set_ylabel("Deviation (A)", fontsize=9)
            self.ax1.set_xticks(x)
            self.ax1.set_xticklabels(lab, rotation=60, ha="right", fontsize=6)
            self.ax1.legend(fontsize=8, facecolor="#2d2d2d", labelcolor="white")
            if has_b:
                self.ax2.plot(x, [r["before"] for r in rows], "o--", color="#ef4444",
                              label="Length before", ms=3)
            self.ax2.plot(x, [r["after"] for r in rows], "s-", color="#3b82f6",
                          label="Length after", ms=3)
            self.ax2.plot(x, [r["target"] for r in rows], "x:", color="#facc15",
                          label="Target", ms=4)
            self.ax2.set_title("Bond lengths vs target", fontsize=10, fontweight="bold")
            self.ax2.set_ylabel("Distance (A)", fontsize=9)
            self.ax2.set_xticks(x)
            self.ax2.set_xticklabels(lab, rotation=60, ha="right", fontsize=6)
            self.ax2.legend(fontsize=8, facecolor="#2d2d2d", labelcolor="white")
            self.fig.tight_layout()
            self.draw()

    class Mol3DCanvas(FigureCanvas):
        """Offline fallback viewer (used when QtWebEngine is unavailable)."""
        def __init__(self):
            self.fig = Figure(figsize=(5, 5), facecolor="#1e1e1e")
            super().__init__(self.fig)
            self.ax = self.fig.add_subplot(111, projection="3d")

        def show_mol(self, mol, sym, X, bad_pairs, labels):
            ax = self.ax
            ax.clear()
            ax.set_facecolor("#1e1e1e")
            ax.set_axis_off()
            bad = {tuple(sorted(p)) for p in bad_pairs}
            for b in mol.GetBonds():
                i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
                isbad = tuple(sorted((i, j))) in bad
                ax.plot(*zip(X[i], X[j]), color="#ef4444" if isbad else "#bbbbbb",
                        ls="--" if isbad else "-", lw=1.4)
            for k, (s, p) in enumerate(zip(sym, X)):
                ax.scatter(*p, s=60 if s != "H" else 25, color=CPK.get(s, "#ff69b4"),
                           edgecolors="#333333", depthshade=False)
            for t, p in labels:
                ax.text(*p, t, color="white", fontsize=7)
            r = max(np.ptp(X, axis=0).max() / 2, 1.0)
            c = X.mean(axis=0)
            ax.set_xlim(c[0] - r, c[0] + r)
            ax.set_ylim(c[1] - r, c[1] + r)
            ax.set_zlim(c[2] - r, c[2] + r)
            self.draw()

    class App(QMainWindow):
        def __init__(self):
            super().__init__()
            self.setWindowTitle("SI-5 SMILES-Authoritative Geometry Validation Suite (v2: normal + hypervalent)")
            self.resize(1500, 900)
            self.path_before = self.path_after = None
            self.mol = None
            self.before = self.after = None
            self.rows = []
            self.notes = []
            self.Xb = self.Xa = None
            self._build()

        # ---------------------------------------------------------- UI
        def _btn(self, bg, hover):
            return (f"QPushButton{{background-color:{bg};color:white;font-weight:bold;"
                    f"padding:8px 16px;border-radius:4px;border:none;}}"
                    f"QPushButton:hover{{background-color:{hover};}}"
                    f"QPushButton:disabled{{background-color:#52525b;color:#a1a1aa;}}")

        def _build(self):
            root = QWidget()
            self.setCentralWidget(root)
            lay = QVBoxLayout(root)
            top = QHBoxLayout()
            lab = QLabel("SMILES:")
            lab.setStyleSheet("font-weight:bold;color:white;")
            self.smiles = QLineEdit("FS(F)(F)(F)(F)c1ccccc1")
            self.smiles.setStyleSheet("background-color:#2d2d2d;color:white;padding:6px;"
                                      "border:1px solid #444;border-radius:4px;")
            self.smiles.setMinimumWidth(340)
            self.smiles.returnPressed.connect(self.run)
            self.b_before = QPushButton("Upload Before .XYZ (optional)")
            self.b_before.setStyleSheet(self._btn("#d97706", "#b45309"))
            self.b_before.clicked.connect(lambda: self.load("before"))
            self.l_before = QLabel("Before: not loaded")
            self.b_after = QPushButton("Upload After .XYZ")
            self.b_after.setStyleSheet(self._btn("#059669", "#047857"))
            self.b_after.clicked.connect(lambda: self.load("after"))
            self.l_after = QLabel("After: not loaded")
            for l in (self.l_before, self.l_after):
                l.setStyleSheet("color:#aaaaaa;font-style:italic;")
            self.b_run = QPushButton("Run validation")
            self.b_run.setStyleSheet(self._btn("#7c3aed", "#6d28d9"))
            self.b_run.clicked.connect(self.run)
            self.b_clear = QPushButton("Clear before")
            self.b_clear.setStyleSheet(self._btn("#52525b", "#3f3f46"))
            self.b_clear.clicked.connect(self.clear_before)
            self.b_export = QPushButton("Export SI-5 report (+CSV/JSON)")
            self.b_export.setStyleSheet(self._btn("#2563eb", "#1d4ed8"))
            self.b_export.clicked.connect(self.export)
            self.b_export.setEnabled(False)
            for w in (lab, self.smiles, self.b_before, self.l_before, self.b_after,
                      self.l_after):
                top.addWidget(w)
            top.addStretch()
            for w in (self.b_clear, self.b_run, self.b_export):
                top.addWidget(w)
            lay.addLayout(top)

            kp = QHBoxLayout()
            self.kpi = {}
            for title, key in [("Verdict (After)", "verdict"),
                               ("Failing bonds (Bef -> Aft)", "bad"),
                               ("Max bond error After", "max"),
                               ("Hypervalent shells OK", "shell"),
                               ("Angles / planarity / clashes", "other")]:
                g = QGroupBox(title)
                g.setStyleSheet("QGroupBox{background-color:#252526;border:1px solid #444;"
                                "border-radius:6px;color:#bbb;font-weight:bold;margin-top:6px;}"
                                "QGroupBox::title{subcontrol-origin:margin;left:10px;padding:0 3px;}")
                v = QVBoxLayout()
                l = QLabel("--")
                l.setStyleSheet("font-size:18px;font-weight:bold;color:#3b82f6;border:none;")
                l.setAlignment(Qt.AlignmentFlag.AlignCenter)
                v.addWidget(l)
                g.setLayout(v)
                self.kpi[key] = l
                kp.addWidget(g)
            lay.addLayout(kp)

            split = QSplitter(Qt.Orientation.Horizontal)
            left = QSplitter(Qt.Orientation.Vertical)
            tstyle = ("QTableWidget{background-color:#1e1e1e;color:#fff;gridline-color:#444;}"
                      "QHeaderView::section{background-color:#2d2d2d;color:white;"
                      "border:1px solid #444;font-weight:bold;}")
            self.tabs_tbl = QTabWidget()
            self.tabs_tbl.setStyleSheet("QTabWidget::pane{border:1px solid #444;}"
                                        "QTabBar::tab{background:#2d2d2d;color:white;padding:6px 12px;font-weight:bold;}"
                                        "QTabBar::tab:selected{background:#2563eb;}")
            self.tbl = QTableWidget()
            self.tbl.setColumnCount(10)
            self.tbl.setHorizontalHeaderLabels(["#", "Bond", "Type", "Target", "Before",
                                                "After", "|D| Bef", "|D| Aft", "Before", "After"])
            self.tbl.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            self.tbl.setStyleSheet(tstyle)
            self.tbl2 = QTableWidget()
            self.tbl2.setColumnCount(6)
            self.tbl2.setHorizontalHeaderLabels(["State", "Item", "Detail", "Value", "Limit", "Status"])
            self.tbl2.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
            self.tbl2.setStyleSheet(tstyle)
            self.tabs_tbl.addTab(self.tbl, "Bond table")
            self.tabs_tbl.addTab(self.tbl2, "Hypervalent shells and issues")
            self.chart = ChartCanvas()
            left.addWidget(self.tabs_tbl)
            left.addWidget(self.chart)
            left.setSizes([380, 380])

            right = QWidget()
            rl = QVBoxLayout(right)
            head = QHBoxLayout()
            t = QLabel("Interactive 3D viewports (red dashed = SMILES bond that fails)")
            t.setStyleSheet("font-weight:bold;font-size:13px;color:#fff;")
            self.chk_all = QCheckBox("show all angles")
            self.chk_all.setStyleSheet("color:white;")
            self.chk_all.stateChanged.connect(self.refresh_views)
            self.chk_off = QCheckBox("offline viewer (no internet needed)")
            self.chk_off.setStyleSheet("color:white;")
            self.chk_off.setChecked(not HAVE_WEB)
            self.chk_off.setEnabled(HAVE_WEB)
            self.chk_off.stateChanged.connect(self.switch_viewer)
            head.addWidget(t)
            head.addStretch()
            head.addWidget(self.chk_off)
            head.addWidget(self.chk_all)
            rl.addLayout(head)
            self.vtabs = QTabWidget()
            self.vtabs.setStyleSheet("QTabWidget::pane{border:1px solid #444;}"
                                     "QTabBar::tab{background:#2d2d2d;color:white;padding:6px 12px;font-weight:bold;}"
                                     "QTabBar::tab:selected{background:#2563eb;}")
            self.mpl = {"before": Mol3DCanvas(), "after": Mol3DCanvas()}
            self.web = {"before": QWebEngineView() if HAVE_WEB else None,
                        "after": QWebEngineView() if HAVE_WEB else None}
            self.stack = {}
            for key, title in (("before", "Before (3D)"), ("after", "After (3D)")):
                st = QStackedWidget()
                st.addWidget(self.mpl[key])
                if HAVE_WEB:
                    st.addWidget(self.web[key])
                    st.setCurrentIndex(0 if self.chk_off.isChecked() else 1)
                self.stack[key] = st
                self.vtabs.addTab(st, title)
            rl.addWidget(self.vtabs)
            split.addWidget(left)
            split.addWidget(right)
            split.setSizes([800, 650])
            lay.addWidget(split)
            self.setStyleSheet("QMainWindow{background-color:#18181b;color:white;}")

        # ------------------------------------------------------ actions
        def load(self, which):
            p, _ = QFileDialog.getOpenFileName(self, f"Open {which} XYZ", "",
                                               "XYZ Files (*.xyz);;All Files (*)")
            if not p:
                return
            self.set_path(which, p)
            self.run()

        def set_path(self, which, p):
            if which == "before":
                self.path_before = p
                self.l_before.setText(f"Before: {os.path.basename(p)}")
            else:
                self.path_after = p
                self.l_after.setText(f"After: {os.path.basename(p)}")

        def clear_before(self):
            self.path_before = None
            self.l_before.setText("Before: not loaded")
            self.run()

        def run(self):
            if not self.path_after:
                return
            try:
                smi = self.smiles.text().strip()
                self.mol = smiles_mol(smi)
                self.Xa, na = load_in_smiles_order(self.mol, self.path_after)
                self.notes = [f"AFTER file: {na}"]
                self.after = gco.check_geometry(self.mol, self.Xa)
                self.before = self.Xb = None
                if self.path_before:
                    self.Xb, nb = load_in_smiles_order(self.mol, self.path_before)
                    self.notes.append(f"BEFORE file: {nb}")
                    self.before = gco.check_geometry(self.mol, self.Xb)
                self.fill()
                self.refresh_views()
                self.b_export.setEnabled(True)
            except Exception as exc:
                QMessageBox.critical(self, "Validation error", str(exc))

        def _item(self, text, bad=None):
            it = QTableWidgetItem(str(text))
            if bad is not None:
                it.setBackground(QBrush(BAD if bad else GOOD))
            return it

        def fill(self):
            a, b, mol = self.after, self.before, self.mol
            sym = [x.GetSymbol() for x in mol.GetAtoms()]
            self.rows = []
            for k, r in enumerate(a["bonds"]):
                rb = b["bonds"][k] if b else None
                self.rows.append(dict(
                    idx=k, bond=f"{sym[r['i']]}{r['i']+1}-{sym[r['j']]}{r['j']+1}",
                    type=f"{r['ei']}-{r['ej']}", target=r["target"],
                    before=rb["dist"] if rb else None, after=r["dist"],
                    dev_before=abs(rb["err"]) if rb else 0.0, dev_after=abs(r["err"]),
                    ok_before=rb["ok"] if rb else None, ok_after=r["ok"],
                    fb=r["source"] == "fallback"))
            self.tbl.setRowCount(len(self.rows))
            for n, d in enumerate(self.rows):
                vals = [d["idx"], d["bond"], d["type"] + ("*" if d["fb"] else ""),
                        f"{d['target']:.3f}",
                        f"{d['before']:.3f}" if d["before"] is not None else "n/a",
                        f"{d['after']:.3f}",
                        f"{d['dev_before']:.3f}" if d["before"] is not None else "n/a",
                        f"{d['dev_after']:.3f}",
                        ("PASS" if d["ok_before"] else "FAIL") if d["before"] is not None else "n/a",
                        "PASS" if d["ok_after"] else "FAIL"]
                for c, v in enumerate(vals):
                    bad = None
                    if c == 8 and d["ok_before"] is not None:
                        bad = not d["ok_before"]
                    if c == 9:
                        bad = not d["ok_after"]
                    self.tbl.setItem(n, c, self._item(v, bad))
            # shells + issues
            items = []
            for st, c in (("Before", b), ("After", a)):
                if c is None:
                    continue
                for h in c["hyper"]:
                    items.append((st, f"{h['element']}{h['centre']+1} shell", h["geometry"],
                                  f"{h['min_angle']:.1f}-{h['max_angle']:.1f} deg; worst dev {h['max_dev']:.1f}",
                                  f"{h['tol']:.0f} deg", h["ok"]))
                for r in c["bad_angles"]:
                    items.append((st, "angle", f"{sym[r['i']]}{r['i']+1}-{r['ec']}{r['c']+1}-{sym[r['j']]}{r['j']+1}",
                                  f"{r['angle']:.1f} deg", f"ideal {r['ideal']:.1f}", False))
                for r in c["bad_planar"]:
                    items.append((st, "planarity", r["kind"] + " " + str([x + 1 for x in r["atoms"]]),
                                  f"{r['max_dev']:.3f}", "", False))
                for r in c["extra_bonds"]:
                    items.append((st, "unintended contact", f"{r['ei']}{r['i']+1}...{r['ej']}{r['j']+1}",
                                  f"{r['dist']:.3f} A", "", False))
                for r in c["missing_bonds"]:
                    items.append((st, "detached bond", f"{r['ei']}{r['i']+1}...{r['ej']}{r['j']+1}",
                                  f"{r['dist']:.3f} A", "", False))
                for r in c["clashes"]:
                    items.append((st, "clash", f"{r['ei']}{r['i']+1}...{r['ej']}{r['j']+1}",
                                  f"{r['dist']:.3f} A", f"< {r['limit']:.2f}", False))
            self.tbl2.setRowCount(len(items))
            for n, (st, item, det, val, lim, ok) in enumerate(items):
                for c, v in enumerate([st, item, det, val, lim, "PASS" if ok else "FAIL"]):
                    self.tbl2.setItem(n, c, self._item(v, (not ok) if c == 5 else None))
            # KPIs
            self.kpi["verdict"].setText(a["verdict"])
            self.kpi["verdict"].setStyleSheet(
                "font-size:18px;font-weight:bold;border:none;color:" +
                ("#10b981" if a["verdict"] == "PASS" else "#ef4444"))
            nb_ = len(b["bad_bonds"]) if b else "n/a"
            self.kpi["bad"].setText(f"{nb_} -> {len(a['bad_bonds'])}")
            self.kpi["max"].setText(f"{a['max_err']:.3f} A")
            self.kpi["shell"].setText(f"{len(a['hyper']) - len(a['bad_hyper'])} / {len(a['hyper'])}")
            self.kpi["other"].setText(f"{len(a['bad_angles'])} / {len(a['bad_planar'])} / {len(a['clashes'])}")
            self.chart.update_plots(self.rows)

        def refresh_views(self):
            if self.mol is None:
                return
            sym = [x.GetSymbol() for x in self.mol.GetAtoms()]
            for key, X, chk in (("before", self.Xb, self.before),
                                ("after", self.Xa, self.after)):
                if X is None:
                    continue
                bad = [(r["i"], r["j"]) for r in chk["bonds"] if not r["ok"]]
                labs = angle_labels(self.mol, X, self.chk_all.isChecked())
                self.mpl[key].show_mol(self.mol, sym, X, bad, labs)
                if HAVE_WEB:
                    self.web[key].setHtml(viewer_html(sym, X, bad, labs))

        def switch_viewer(self):
            if HAVE_WEB:
                for st in self.stack.values():
                    st.setCurrentIndex(0 if self.chk_off.isChecked() else 1)

        def export(self):
            if not self.after:
                return
            p, _ = QFileDialog.getSaveFileName(self, "Export SI-5 report",
                                               "SI_5_Report.txt", "Text Files (*.txt)")
            if not p:
                return
            try:
                stem = os.path.splitext(p)[0]
                smi = self.smiles.text().strip()
                with open(p, "w", encoding="utf-8") as fh:
                    fh.write(si_report_text(smi, self.mol, self.before, self.after,
                                            self.notes))
                write_outputs(stem, smi, self.mol, self.after, self.before, self.notes)
                QMessageBox.information(self, "Export successful",
                                        f"Saved:\n{p}\n{stem}_bonds.csv\n{stem}_summary.json\n{stem}_report.txt")
            except Exception as exc:
                QMessageBox.critical(self, "Export error", str(exc))

    app = QApplication.instance() or QApplication(sys.argv)
    win = App()
    win.show()
    return app, win


def gui_main():
    app, win = launch_gui()
    sys.exit(app.exec())


def main():
    if len(sys.argv) > 1:
        cli_main()
    else:
        gui_main()


if __name__ == "__main__":
    main()

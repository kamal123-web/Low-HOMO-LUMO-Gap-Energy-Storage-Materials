#!/usr/bin/env python3
"""
======================================================================
G3  -  UNIFIED SMILES-AUTHORITATIVE GEOMETRY ENGINE
        (normal + hypervalent + heavy-element molecules, one code path)
======================================================================
Drop-in replacement for the G1 / G2 `repair_structure()` function.

Pipeline (identical for every molecule - no element-based branching):
  1. SMILES -> RDKit molecule with explicit H.  The SMILES is the ONLY
     authority on atoms, bonds and bond orders.
  2. A target is built for every bond (geom_common.target_length), every
     angle (VSEPR templates for hypervalent centres, hybridisation rules for
     everything else) and every planarity / ester-torsion requirement.
  3. Distance-geometry embedding using a bounds matrix that contains those
     targets (so even S(VI), I(III), I(V), P(V), Xe are embedded correctly).
  4. Restrained minimisation (analytic gradients): bonds + angles +
     planarity + 1-4 + steric repulsion.
  5. Multi-start; every candidate is audited by geom_common.check_geometry
     and the best PASSING one is kept.  If none passes, status is
     UNRESOLVED (never a silent "PASS").

The input XYZ (optional) is only used to (a) verify the composition and
(b) carry extra columns across when the atom mapping is exact.
Geometries are idealised (template-built + restrained); they are starting
structures for ASE/PySCF, not relaxed minima.
"""
import math
import os
import sys

import numpy as np
from scipy.optimize import minimize
from rdkit import Chem, RDLogger
from rdkit.Chem import AllChem, rdDistGeom
from rdkit.Chem.Draw import rdMolDraw2D
from rdkit.DistanceGeometry import DoTriangleSmoothing

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import geom_common as gco  # noqa: E402  (never name it "gc": that shadows the stdlib garbage-collector module)

RDLogger.DisableLog("rdApp.*")

ENGINE_NONBONDED_FACTOR = 0.72     # repulsion onset (validator uses 0.65)


# --------------------------------------------------------------------------
# I/O helpers (same file formats as G1)
# --------------------------------------------------------------------------
def parse_extended_xyz(filename):
    if not filename or not os.path.isfile(filename):
        raise FileNotFoundError(f"File not found: {filename}")
    with open(filename, "r", encoding="utf-8", errors="ignore") as fh:
        raw = fh.readlines()
    declared = int(raw[0].split()[0])
    comment = raw[1].strip() if len(raw) > 1 else ""
    sym, xyz, extra = [], [], []
    for line in raw[2:]:
        p = line.split()
        if len(p) < 4:
            continue
        try:
            xyz.append([float(p[1]), float(p[2]), float(p[3])])
        except ValueError:
            continue
        sym.append(p[0])
        extra.append(p[4:])
    if len(sym) != declared:
        raise ValueError(f"XYZ atom count mismatch: header={declared}, "
                         f"parsed={len(sym)}")
    return comment, sym, np.asarray(xyz, float), extra


def write_extended_xyz(filename, comment, symbols, coords, extra_cols=None):
    with open(filename, "w", encoding="utf-8") as fh:
        fh.write(f"{len(symbols)}\n{comment}\n")
        for k, (s, p) in enumerate(zip(symbols, coords)):
            ex = ""
            if extra_cols is not None and extra_cols[k]:
                ex = " " + " ".join(extra_cols[k])
            fh.write(f"{s:<3s} {p[0]:16.8f} {p[1]:16.8f} {p[2]:16.8f}{ex}\n")


def write_sdf(mol, coords, filename):
    out = Chem.Mol(mol)
    out.RemoveAllConformers()
    conf = Chem.Conformer(out.GetNumAtoms())
    for i, p in enumerate(coords):
        conf.SetAtomPosition(i, tuple(float(v) for v in p))
    out.AddConformer(conf, assignId=True)
    w = Chem.SDWriter(filename)
    w.write(out)
    w.close()


def write_2d_png(smiles, filename):
    try:
        m = Chem.MolFromSmiles(smiles)
        AllChem.Compute2DCoords(m)
        d = rdMolDraw2D.MolDraw2DCairo(900, 700)
        d.DrawMolecule(m)
        d.FinishDrawing()
        with open(filename, "wb") as fh:
            fh.write(d.GetDrawingText())
    except Exception as exc:                    # drawing is cosmetic only
        print(f"[WARN] 2D drawing skipped: {exc}")


def build_reference_molecule(smiles):
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        raise ValueError(f"Invalid SMILES string: {smiles}")
    Chem.SanitizeMol(mol)
    return Chem.AddHs(mol)


# --------------------------------------------------------------------------
# Restraint specification
# --------------------------------------------------------------------------
def d13(a, b, theta_deg):
    th = math.radians(theta_deg)
    return math.sqrt(max(a * a + b * b - 2 * a * b * math.cos(th), 1e-6))


def d14(l12, l23, l34, th2, th3, phi):
    """1-4 distance for torsion phi (deg) given lengths and the two angles."""
    t2, t3, ph = map(math.radians, (th2, th3, phi))
    p1 = np.array([l12 * math.cos(math.pi - t2), l12 * math.sin(math.pi - t2), 0])
    p2 = np.array([0.0, 0.0, 0.0])
    p3 = np.array([l23, 0.0, 0.0])
    p4 = p3 + l34 * np.array([-math.cos(math.pi - t3),
                              math.sin(math.pi - t3) * math.cos(ph),
                              math.sin(math.pi - t3) * math.sin(ph)])
    # p1 placed so angle at p2 is th2:   fix orientation explicitly
    p1 = np.array([l12 * math.cos(t2), l12 * math.sin(t2), 0.0])
    p4 = p3 + l34 * np.array([-math.cos(t3), math.sin(t3) * math.cos(ph),
                              math.sin(t3) * math.sin(ph)])
    return float(np.linalg.norm(p1 - p4))


class Spec:
    def __init__(self, mol):
        self.mol = mol
        n = mol.GetNumAtoms()
        self.n = n
        self.sym = [a.GetSymbol() for a in mol.GetAtoms()]
        self.dm = Chem.GetDistanceMatrix(mol)

        self.bond_t = {}
        for b in mol.GetBonds():
            i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
            self.bond_t[(min(i, j), max(i, j))] = gco.target_length(mol, b)[0]
        self.L = lambda i, j: self.bond_t[(min(i, j), max(i, j))]

        # angles --------------------------------------------------------
        self.angles = []              # (i, c, j, theta)
        self.hyper = gco.hyper_centres(mol)
        for a in mol.GetAtoms():
            c = a.GetIdx()
            nb = [x.GetIdx() for x in a.GetNeighbors()]
            if len(nb) < 2:
                continue
            if c in self.hyper:
                geom, assign = gco.assign_sites(mol, c)
                T = gco.template_angle_matrix(geom)
                for (n1, s1) in assign:
                    for (n2, s2) in assign:
                        if n1 < n2:
                            self.angles.append((n1, c, n2, float(T[s1, s2])))
            else:
                for p in range(len(nb)):
                    for q in range(p + 1, len(nb)):
                        th = gco.ideal_angle_nonhyper(mol, c, nb[p], nb[q])
                        self.angles.append((nb[p], c, nb[q], th))
        self.ang_lookup = {(min(i, j), c, max(i, j)): th
                           for i, c, j, th in self.angles}

        # planarity quartets (centre, a, b, d) --------------------------
        self.planar = []
        for a in mol.GetAtoms():
            c = a.GetIdx()
            if c in self.hyper or a.GetDegree() != 3:
                continue
            if a.GetSymbol() in ("C", "N") and gco.hyb(a) == 2:
                nb = [x.GetIdx() for x in a.GetNeighbors()]
                self.planar.append((c, nb[0], nb[1], nb[2]))

        # ester / carboxylate:  X-O-C(=O) coplanar and cis ----------------
        self.d14 = []                 # (i, l, dist)
        for a in mol.GetAtoms():
            if a.GetSymbol() != "O" or a.GetDegree() != 2:
                continue
            o = a.GetIdx()
            for cbn in a.GetNeighbors():
                if not gco.is_carbonyl_c(cbn):
                    continue
                x = [k.GetIdx() for k in a.GetNeighbors()
                     if k.GetIdx() != cbn.GetIdx()][0]
                c = cbn.GetIdx()
                od = [k.GetIdx() for k in cbn.GetNeighbors()
                      if k.GetSymbol() == "O" and
                      mol.GetBondBetweenAtoms(c, k.GetIdx())
                      .GetBondTypeAsDouble() == 2]
                if not od:
                    continue
                od = od[0]
                self.planar.append((o, x, c, od))
                th_o = self.ang_lookup[(min(x, c), o, max(x, c))]
                th_c = self.ang_lookup[(min(o, od), c, max(o, od))]
                self.d14.append((x, od, d14(self.L(x, o), self.L(o, c),
                                            self.L(c, od), th_o, th_c, 0.0)))

        # aromatic-ring planarity quartets: ring torsion 0 / exo 180 ----------
        self.d14_ring = []
        for ring in mol.GetRingInfo().AtomRings():
            if not all(mol.GetAtomWithIdx(k).GetIsAromatic() for k in ring):
                continue
            m = len(ring)
            for k in range(m):
                p = [ring[(k + t) % m] for t in range(4)]
                th2 = self.ang_lookup.get((min(p[0], p[2]), p[1], max(p[0], p[2])))
                th3 = self.ang_lookup.get((min(p[1], p[3]), p[2], max(p[1], p[3])))
                if th2 is None or th3 is None:
                    continue
                self.d14_ring.append((p[0], p[3], d14(
                    self.L(p[0], p[1]), self.L(p[1], p[2]), self.L(p[2], p[3]),
                    th2, th3, 0.0)))
            for r in ring:
                for ex in mol.GetAtomWithIdx(r).GetNeighbors():
                    e = ex.GetIdx()
                    if e in ring:
                        continue
                    for pn in mol.GetAtomWithIdx(r).GetNeighbors():
                        p = pn.GetIdx()
                        if p not in ring:
                            continue
                        for pp in mol.GetAtomWithIdx(p).GetNeighbors():
                            q = pp.GetIdx()
                            if q not in ring or q == r:
                                continue
                            th2 = self.ang_lookup.get((min(e, p), r, max(e, p)))
                            th3 = self.ang_lookup.get((min(r, q), p, max(r, q)))
                            if th2 is None or th3 is None:
                                continue
                            self.d14_ring.append((e, q, d14(
                                self.L(e, r), self.L(r, p), self.L(p, q),
                                th2, th3, 180.0)))

        # steric repulsion pairs ---------------------------------------
        pairs = []
        for i in range(n):
            for j in range(i + 1, n):
                if self.dm[i][j] >= 3:
                    dmin = ENGINE_NONBONDED_FACTOR * (gco.vdw(self.sym[i]) +
                                                      gco.vdw(self.sym[j]))
                    pairs.append((i, j, dmin))
        self.rep = pairs

        self._arrays()

    def _arrays(self):
        bi = np.array([k[0] for k in self.bond_t], int)
        bj = np.array([k[1] for k in self.bond_t], int)
        self.bi, self.bj = bi, bj
        self.bd = np.array([self.bond_t[k] for k in self.bond_t])
        A = np.array([[a[0], a[1], a[2]] for a in self.angles], int).reshape(-1, 3)
        self.ai, self.ac, self.aj = A[:, 0], A[:, 1], A[:, 2]
        th = np.array([a[3] for a in self.angles])
        self.acos0 = np.cos(np.radians(th))
        self.alin = th >= 175.0
        self.asin2 = np.maximum(np.sin(np.radians(th)) ** 2, 1e-3)
        P = np.array(self.planar, int).reshape(-1, 4)
        self.pc, self.pa, self.pb, self.pd = P[:, 0], P[:, 1], P[:, 2], P[:, 3]
        D = self.d14 + self.d14_ring
        self.ti = np.array([d[0] for d in D], int)
        self.tj = np.array([d[1] for d in D], int)
        self.td = np.array([d[2] for d in D])
        R = self.rep
        self.ri = np.array([r[0] for r in R], int)
        self.rj = np.array([r[1] for r in R], int)
        self.rd = np.array([r[2] for r in R])


# --------------------------------------------------------------------------
# Energy + analytic gradient
# --------------------------------------------------------------------------
def energy_grad(x, sp, w):
    X = x.reshape(-1, 3)
    g = np.zeros_like(X)
    E = 0.0

    d = X[sp.bi] - X[sp.bj]
    r = np.linalg.norm(d, axis=1) + 1e-12
    dr = r - sp.bd
    E += w["b"] * np.sum(dr ** 2)
    gb = (2 * w["b"] * dr / r)[:, None] * d
    np.add.at(g, sp.bi, gb)
    np.add.at(g, sp.bj, -gb)

    if len(sp.ai):
        u = X[sp.ai] - X[sp.ac]
        v = X[sp.aj] - X[sp.ac]
        nu = np.linalg.norm(u, axis=1) + 1e-12
        nv = np.linalg.norm(v, axis=1) + 1e-12
        c = np.sum(u * v, axis=1) / (nu * nv)
        c = np.clip(c, -1, 1)
        E_lin = w["a"] * (1.0 + c)
        E_gen = w["a"] * (c - sp.acos0) ** 2 / sp.asin2
        dE = np.where(sp.alin, w["a"], 2 * w["a"] * (c - sp.acos0) / sp.asin2)
        E += np.sum(np.where(sp.alin, E_lin, E_gen))
        dci = v / (nu * nv)[:, None] - (c / nu ** 2)[:, None] * u
        dcj = u / (nu * nv)[:, None] - (c / nv ** 2)[:, None] * v
        np.add.at(g, sp.ai, dE[:, None] * dci)
        np.add.at(g, sp.aj, dE[:, None] * dcj)
        np.add.at(g, sp.ac, -dE[:, None] * (dci + dcj))

    if len(sp.pc):
        a = X[sp.pa] - X[sp.pc]
        b = X[sp.pb] - X[sp.pc]
        dd = X[sp.pd] - X[sp.pc]
        V = np.sum(a * np.cross(b, dd), axis=1)
        E += w["p"] * np.sum(V ** 2)
        f = (2 * w["p"] * V)[:, None]
        ga, gb_, gd = f * np.cross(b, dd), f * np.cross(dd, a), f * np.cross(a, b)
        np.add.at(g, sp.pa, ga)
        np.add.at(g, sp.pb, gb_)
        np.add.at(g, sp.pd, gd)
        np.add.at(g, sp.pc, -(ga + gb_ + gd))

    if len(sp.ti):
        d = X[sp.ti] - X[sp.tj]
        r = np.linalg.norm(d, axis=1) + 1e-12
        dr = r - sp.td
        E += w["t"] * np.sum(dr ** 2)
        gt = (2 * w["t"] * dr / r)[:, None] * d
        np.add.at(g, sp.ti, gt)
        np.add.at(g, sp.tj, -gt)

    if len(sp.ri):
        d = X[sp.ri] - X[sp.rj]
        r = np.linalg.norm(d, axis=1) + 1e-12
        m = r < sp.rd
        if m.any():
            dr = (r - sp.rd)[m]
            E += w["r"] * np.sum(dr ** 2)
            gr = (2 * w["r"] * dr / r[m])[:, None] * d[m]
            np.add.at(g, sp.ri[m], gr)
            np.add.at(g, sp.rj[m], -gr)
    return E, g.ravel()


def refine(X0, sp):
    x = X0.ravel().copy()
    stages = [dict(b=100, a=40, p=60, t=30, r=30),
              dict(b=400, a=150, p=200, t=100, r=60),
              dict(b=1500, a=500, p=600, t=300, r=100)]
    for w in stages:
        r = minimize(energy_grad, x, args=(sp, w), jac=True, method="L-BFGS-B",
                     options=dict(maxiter=4000, ftol=1e-14, gtol=1e-8))
        x = r.x
    E, _ = energy_grad(x, sp, stages[-1])
    return x.reshape(-1, 3), float(E)


# --------------------------------------------------------------------------
# Embedding
# --------------------------------------------------------------------------
def embed(mol, sp, seed):
    n = mol.GetNumAtoms()
    try:
        bm = rdDistGeom.GetMoleculeBoundsMatrix(mol)
        for (i, j), t in sp.bond_t.items():
            tol = 0.04 if "I" not in (sp.sym[i], sp.sym[j]) else 0.08
            bm[i, j], bm[j, i] = t + tol, t - tol
        for (i, c, j, th) in sp.angles:
            dd = d13(sp.L(i, c), sp.L(c, j), th)
            a, b = min(i, j), max(i, j)
            wd = 0.10 if th < 175 else 0.05
            bm[a, b], bm[b, a] = dd + wd, max(dd - wd, 0.5)
        if DoTriangleSmoothing(bm):
            ps = rdDistGeom.EmbedParameters()
            ps.randomSeed = int(seed)
            ps.useRandomCoords = True
            ps.useExpTorsionAnglePrefs = False
            ps.useBasicKnowledge = False
            ps.SetBoundsMat(bm)
            m2 = Chem.Mol(mol)
            if rdDistGeom.EmbedMolecule(m2, ps) == 0:
                return np.asarray(m2.GetConformer().GetPositions(), float)
    except Exception:
        pass
    rng = np.random.default_rng(seed)
    return rng.normal(scale=2.0, size=(n, 3))


# --------------------------------------------------------------------------
# Optional input mapping (only to carry extra columns across)
# --------------------------------------------------------------------------
def map_input(mol, xs, xc):
    """Exact graph mapping of XYZ atoms to SMILES atoms, or None."""
    if sorted(xs) != sorted(a.GetSymbol() for a in mol.GetAtoms()):
        raise ValueError("Composition of the XYZ does not match the SMILES: "
                         f"{sorted(xs)} vs "
                         f"{sorted(a.GetSymbol() for a in mol.GetAtoms())}")
    if list(xs) == [a.GetSymbol() for a in mol.GetAtoms()]:
        # same order: accept only if the perceived connectivity agrees
        ok = True
        for b in mol.GetBonds():
            i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
            if np.linalg.norm(xc[i] - xc[j]) > 1.35 * (gco.cov(xs[i]) +
                                                        gco.cov(xs[j])) + 0.4:
                ok = False
        if ok:
            return list(range(len(xs)))
    q = Chem.RWMol()
    for s in xs:
        q.AddAtom(Chem.Atom(s))
    for i in range(len(xs)):
        for j in range(i + 1, len(xs)):
            if np.linalg.norm(xc[i] - xc[j]) <= 1.25 * (gco.cov(xs[i]) +
                                                         gco.cov(xs[j])):
                q.AddBond(i, j, Chem.BondType.SINGLE)
    ref = Chem.RWMol(mol)
    for a in ref.GetAtoms():
        a.SetIsAromatic(False)
        a.SetFormalCharge(0)
        a.SetNoImplicit(True)
    for b in ref.GetBonds():
        b.SetBondType(Chem.BondType.SINGLE)
        b.SetIsAromatic(False)
    qm, rm = q.GetMol(), ref.GetMol()
    if qm.GetNumBonds() != rm.GetNumBonds():
        return None
    match = qm.GetSubstructMatch(rm)       # ref atom k -> xyz atom match[k]
    return list(match) if match and len(match) == len(xs) else None


# --------------------------------------------------------------------------
# Public API
# --------------------------------------------------------------------------
def build_geometry(smiles, n_seeds=24, stop_after=6, verbose=True):
    mol = build_reference_molecule(smiles)
    sp = Spec(mol)
    best, passing = None, 0
    for seed in range(n_seeds):
        X, E = refine(embed(mol, sp, seed), sp)
        chk = gco.check_geometry(mol, X)
        key = (len(chk["reasons"]), E)
        if best is None or key < best[0]:
            best = (key, X, E, chk, seed)
        if chk["verdict"] == "PASS":
            passing += 1
            if passing >= stop_after:
                break
    _, X, E, chk, seed = best
    # centre at origin
    X = X - X.mean(axis=0)
    if verbose:
        print(f"[G3] seed={seed} restraint_energy={E:.4f} "
              f"verdict={chk['verdict']} max_bond_err={chk['max_err']:.4f}")
    return mol, X, chk, seed


def repair_structure(smiles, input_xyz=None, output_xyz="corrected.xyz",
                     output_sdf="corrected.sdf", output_png="structure_2d.png",
                     output_report="validation_report.txt"):
    print("\n" + "=" * 78 +
          "\nG3 UNIFIED SMILES-AUTHORITATIVE GEOMETRY ENGINE\n" + "=" * 78)
    mol, X, chk, seed = build_geometry(smiles)
    symbols = [a.GetSymbol() for a in mol.GetAtoms()]

    comment, extra = f"G3 | {smiles}", None
    map_note = "no input XYZ supplied"
    if input_xyz:
        try:
            c0, xs, xc, ex = parse_extended_xyz(input_xyz)
            comment = c0 or comment
            mp = map_input(mol, xs, xc)
            if mp is None:
                map_note = ("input XYZ composition OK but atom mapping not "
                            "unique (broken topology) - extra columns dropped")
            else:
                extra = [ex[mp[k]] for k in range(len(symbols))]
                map_note = "input XYZ mapped exactly; extra columns carried"
        except Exception as exc:
            map_note = f"input XYZ not used: {exc}"
    print(f"[G3] {map_note}")

    conf = Chem.Conformer(mol.GetNumAtoms())
    for i, p in enumerate(X):
        conf.SetAtomPosition(i, tuple(float(v) for v in p))
    mol.RemoveAllConformers()
    mol.AddConformer(conf, assignId=True)

    write_extended_xyz(output_xyz, comment, symbols, X, extra)
    write_sdf(mol, X, output_sdf)
    write_2d_png(smiles, output_png)
    with open(output_report, "w", encoding="utf-8") as fh:
        fh.write("G3 SMILES-AUTHORITATIVE GEOMETRY REPORT\n" + "=" * 78 + "\n")
        fh.write(f"SMILES: {smiles}\nverdict: {chk['verdict']}\n")
        fh.write(f"max bond error: {chk['max_err']:.4f} A   "
                 f"rms: {chk['rms_err']:.4f} A\n")
        for r in chk["bonds"]:
            fh.write(f"{r['i']:3d} {r['ei']:>2s}-{r['j']:3d} {r['ej']:<2s} "
                     f"d={r['dist']:.4f} target={r['target']:.4f} "
                     f"{'PASS' if r['ok'] else 'FAIL'}\n")
        for r in chk["hyper"]:
            fh.write(f"hypervalent {r['element']}{r['centre']} {r['geometry']}"
                     f" max dev {r['max_dev']:.1f} deg "
                     f"{'PASS' if r['ok'] else 'FAIL'}\n")
        for s in chk["reasons"]:
            fh.write(f"ISSUE: {s}\n")

    final = dict(report=chk["bonds"], bad=chk["bad_bonds"],
                 clashes=chk["clashes"], max_error=chk["max_err"],
                 mean_error=chk["mean_err"], check=chk)
    status = "PASS" if chk["verdict"] == "PASS" else "UNRESOLVED"
    print(f"FINAL STATUS: {status}")
    return mol, X, final


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python g3_engine.py 'SMILES' [prefix]")
        sys.exit(1)
    pre = sys.argv[2] if len(sys.argv) > 2 else "g3_out"
    repair_structure(sys.argv[1], None, f"{pre}.xyz", f"{pre}.sdf",
                     f"{pre}.png", f"{pre}_report.txt")

#!/usr/bin/env python3
"""
geom_common.py  -  single source of truth shared by the G3 repair engine and
the validator.  Contains:

  * element data (covalent / vdW radii, valence electrons)
  * context-aware bond-length targets          -> target_length()
  * VSEPR classification of every atom         -> classify_atom()
  * hypervalent shell templates + site rules   -> TEMPLATES, assign_sites()
  * ideal angles for ordinary (non-hypervalent) atoms -> ideal_angle_nonhyper()
  * check_geometry(): the full geometry audit used by both programs
"""
import itertools
import math

import numpy as np
from rdkit import Chem

# --------------------------------------------------------------------------
# Element data
# --------------------------------------------------------------------------
COV_R = {"H": 0.31, "B": 0.85, "C": 0.76, "N": 0.71, "O": 0.66, "F": 0.57,
         "Si": 1.11, "P": 1.07, "S": 1.05, "Cl": 1.02, "Br": 1.20,
         "I": 1.39, "Xe": 1.40, "As": 1.19, "Se": 1.20, "Te": 1.38}
VDW_R = {"H": 1.10, "B": 1.92, "C": 1.70, "N": 1.55, "O": 1.52, "F": 1.47,
         "Si": 2.10, "P": 1.80, "S": 1.80, "Cl": 1.75, "Br": 1.85,
         "I": 1.98, "Xe": 2.16, "As": 1.85, "Se": 1.90, "Te": 2.06}
VALENCE_E = {"H": 1, "B": 3, "C": 4, "N": 5, "O": 6, "F": 7, "Si": 4, "P": 5,
             "S": 6, "Cl": 7, "Br": 7, "I": 7, "Xe": 8, "As": 5, "Se": 6,
             "Te": 6}
EN = {"H": 2.2, "B": 2.0, "C": 2.5, "N": 3.0, "O": 3.5, "F": 4.0, "Si": 1.9,
      "P": 2.2, "S": 2.5, "Cl": 3.0, "Br": 2.8, "I": 2.5, "Xe": 2.6,
      "As": 2.2, "Se": 2.5, "Te": 2.1}


def cov(sym):
    return COV_R.get(sym, 0.90)


def vdw(sym):
    return VDW_R.get(sym, 1.90)


# --------------------------------------------------------------------------
# Small atom helpers
# --------------------------------------------------------------------------
def hyb(atom):
    """1 = sp, 2 = sp2/aromatic, 3 = sp3 (from bond orders, not RDKit tags)."""
    orders = [b.GetBondTypeAsDouble() for b in atom.GetBonds()]
    if any(o >= 3 for o in orders) or sum(o == 2 for o in orders) >= 2:
        return 1
    if any(o in (1.5, 2) for o in orders):
        return 2
    return 3


def has_double_to(atom, symbols=("O", "N", "S")):
    for b in atom.GetBonds():
        if b.GetBondTypeAsDouble() == 2:
            if b.GetOtherAtom(atom).GetSymbol() in symbols:
                return True
    return False


def is_carbonyl_c(atom):
    return atom.GetSymbol() == "C" and has_double_to(atom, ("O", "N", "S"))


def ring_of(mol, size, *atoms):
    for ring in mol.GetRingInfo().AtomRings():
        if len(ring) == size and all(a in ring for a in atoms):
            return ring
    return None


# --------------------------------------------------------------------------
# VSEPR classification
# --------------------------------------------------------------------------
def classify_atom(atom):
    """Return dict(deg, lp, domains, geometry, hyper)."""
    sym = atom.GetSymbol()
    deg = atom.GetDegree()
    ve = VALENCE_E.get(sym)
    if ve is None or deg == 0:
        return dict(deg=deg, lp=0, domains=deg, geometry="NONE", hyper=False)
    valence = sum(b.GetBondTypeAsDouble() for b in atom.GetBonds())
    if atom.GetIsAromatic():          # aromatic heteroatom (thiophene S etc.)
        valence = atom.GetTotalValence()
    lp = max(0, int(round((ve - atom.GetFormalCharge() - valence) / 2.0)))
    domains = deg + lp
    geom = {
        (6, 0): "OCT", (5, 0): "TBP", (5, 1): "SQPYR", (4, 1): "SEESAW",
        (4, 2): "SQPLANAR", (3, 2): "TSHAPE", (2, 3): "LINEAR",
    }.get((deg, lp), "NONHYPER")
    hyper = domains >= 5 and deg >= 2 and geom != "NONHYPER"
    return dict(deg=deg, lp=lp, domains=domains, geometry=geom, hyper=hyper)


def hyper_centres(mol):
    return [a.GetIdx() for a in mol.GetAtoms() if classify_atom(a)["hyper"]]


# --------------------------------------------------------------------------
# Hypervalent templates (unit vectors of the ligand sites)
# --------------------------------------------------------------------------
def _v(*a):
    v = np.array(a, float)
    return v / np.linalg.norm(v)


_c55, _s55 = math.cos(math.radians(55)), math.sin(math.radians(55))
TEMPLATES = {
    "LINEAR": np.array([_v(0, 0, 1), _v(0, 0, -1)]),
    "TSHAPE": np.array([_v(0, 0, 1), _v(0, 0, -1), _v(1, 0, 0)]),
    "SEESAW": np.array([_v(0, 0, 1), _v(0, 0, -1),
                        _v(_c55, _s55, 0), _v(_c55, -_s55, 0)]),
    "TBP": np.array([_v(0, 0, 1), _v(0, 0, -1), _v(1, 0, 0),
                     _v(-.5, math.sqrt(3) / 2, 0),
                     _v(-.5, -math.sqrt(3) / 2, 0)]),
    "OCT": np.array([_v(0, 0, 1), _v(0, 0, -1), _v(1, 0, 0), _v(-1, 0, 0),
                     _v(0, 1, 0), _v(0, -1, 0)]),
    "SQPYR": np.array([_v(0, 0, 1), _v(1, 0, 0), _v(0, 1, 0), _v(-1, 0, 0),
                       _v(0, -1, 0)]),
    "SQPLANAR": np.array([_v(1, 0, 0), _v(-1, 0, 0), _v(0, 1, 0),
                          _v(0, -1, 0)]),
}
# angular tolerance (deg) used by the validator for each shell shape
SHAPE_TOL = {"LINEAR": 12.0, "TSHAPE": 15.0, "SEESAW": 20.0, "TBP": 12.0,
             "OCT": 12.0, "SQPYR": 15.0, "SQPLANAR": 12.0}


def template_angle_matrix(name):
    t = TEMPLATES[name]
    c = np.clip(t @ t.T, -1, 1)
    return np.degrees(np.arccos(c))


def ax_score(mol, centre, nbr):
    """Higher = prefers an axial site (electronegative, single-bonded)."""
    a = mol.GetAtomWithIdx(nbr)
    b = mol.GetBondBetweenAtoms(centre, nbr)
    s = EN.get(a.GetSymbol(), 2.5)
    if b.GetBondTypeAsDouble() >= 2:
        s -= 5.0
    if a.GetSymbol() == "C" and a.GetIsAromatic():
        s -= 0.6
    return s


def assign_sites(mol, centre):
    """Return (geometry, [(neighbour_idx, site_idx), ...]) for a hypervalent
    centre following the usual VSEPR/Bent's-rule placement rules."""
    atom = mol.GetAtomWithIdx(centre)
    info = classify_atom(atom)
    geom = info["geometry"]
    nbrs = [n.GetIdx() for n in atom.GetNeighbors()]
    scores = {n: ax_score(mol, centre, n) for n in nbrs}
    if geom in ("OCT", "SQPYR"):
        order = sorted(nbrs, key=lambda n: scores[n])        # lowest first
    else:
        order = sorted(nbrs, key=lambda n: -scores[n])       # highest first
    return geom, [(n, s) for s, n in enumerate(order)]


# --------------------------------------------------------------------------
# Bond-length targets (Angstrom)
# --------------------------------------------------------------------------
_CC_SINGLE = {(3, 3): 1.53, (2, 3): 1.51, (1, 3): 1.47, (2, 2): 1.48,
              (1, 2): 1.44, (1, 1): 1.38}


def _o_has_h(atom):
    return any(n.GetSymbol() == "H" for n in atom.GetNeighbors())


def target_length(mol, bond):
    """Return (length, source) with source 'table' or 'fallback'."""
    a1, a2 = bond.GetBeginAtom(), bond.GetEndAtom()
    s1, s2 = a1.GetSymbol(), a2.GetSymbol()
    key = tuple(sorted((s1, s2)))
    o = bond.GetBondTypeAsDouble()

    def other(sym):
        return a1 if a1.GetSymbol() == sym else a2

    t = None
    if key == ("C", "H"):
        c = other("C")
        t = {1: 1.06, 2: 1.08, 3: 1.09}[hyb(c)]
    elif key == ("H", "O"):
        t = 0.96
    elif key == ("H", "N"):
        t = 1.01
    elif key == ("H", "S"):
        t = 1.34
    elif key == ("C", "C"):
        if o >= 3:
            t = 1.20
        elif o == 2:
            t = 1.34
        elif o == 1.5:
            t = 1.40
            r5 = None
            for ring in mol.GetRingInfo().AtomRings():
                if (len(ring) == 5 and a1.GetIdx() in ring
                        and a2.GetIdx() in ring
                        and any(mol.GetAtomWithIdx(x).GetSymbol() == "S"
                                for x in ring)):
                    r5 = ring
            if r5 is not None:
                near_s = any(n.GetSymbol() == "S" and n.GetIdx() in r5
                             for a in (a1, a2) for n in a.GetNeighbors())
                t = 1.37 if near_s else 1.42
        else:
            h = tuple(sorted((hyb(a1), hyb(a2))))
            t = _CC_SINGLE.get(h, 1.52)
    elif key == ("C", "F"):
        c = other("C")
        nF = sum(n.GetSymbol() == "F" for n in c.GetNeighbors())
        t = 1.35 if hyb(c) == 2 else (1.33 if nF >= 2 else 1.34)
    elif key == ("C", "N"):
        c = other("C")
        t = {3: 1.16, 2: 1.28, 1.5: 1.34}.get(o)
        if t is None:
            t = 1.40 if hyb(c) == 2 else 1.47
    elif key == ("C", "O"):
        c = other("C")
        if o == 2:
            t = 1.21
        elif c.GetIsAromatic():
            t = 1.37
        elif is_carbonyl_c(c):
            t = 1.34
        elif hyb(c) == 2:
            t = 1.36
        else:
            t = 1.43
    elif key == ("C", "S"):
        c = other("C")
        t = 1.71 if o == 1.5 else (1.60 if o == 2 else
                                    (1.77 if hyb(c) == 2 else 1.82))
    elif key == ("C", "Cl"):
        t = 1.74 if hyb(other("C")) == 2 else 1.78
    elif key == ("Br", "C"):
        t = 1.90 if hyb(other("C")) == 2 else 1.95
    elif key == ("C", "I"):
        t = 2.10 if hyb(other("C")) == 2 else 2.16
    elif key == ("C", "P"):
        t = 1.80
    elif key == ("C", "Si"):
        t = 1.87
    elif key == ("C", "Xe"):
        t = 2.35
    elif key == ("F", "S"):
        t = 1.58
    elif key == ("Cl", "S"):
        t = 2.05
    elif key == ("O", "S"):
        t = 1.45 if o == 2 else 1.65
    elif key == ("N", "S"):
        t = 1.65
    elif key == ("S", "S"):
        t = 2.05
    elif key == ("F", "P"):
        t = 1.58
    elif key == ("Cl", "P"):
        t = 2.04
    elif key == ("O", "P"):
        t = 1.48 if o == 2 else 1.60
    elif key == ("F", "I"):
        t = 2.00
    elif key == ("Cl", "I"):
        t = 2.45
    elif key == ("I", "O"):
        if o == 2:
            t = 1.80
        else:
            t = 2.00 if _o_has_h(other("O")) else 2.15
    elif key == ("I", "N"):
        t = 2.10
    elif key == ("F", "Xe"):
        t = 2.00
    elif key == ("N", "O"):
        oo, nn = other("O"), other("N")
        if o == 2 or oo.GetFormalCharge() < 0 or nn.GetFormalCharge() > 0:
            t = 1.23                       # nitro / N-oxide type
        else:
            t = 1.40
    elif key == ("N", "N"):
        t = 1.45 if o == 1 else 1.25
    if t is not None:
        return float(t), "table"
    return float(cov(s1) + cov(s2)), "fallback"


# --------------------------------------------------------------------------
# Ideal angles for ordinary atoms
# --------------------------------------------------------------------------
def _interior_5(mol, centre, ring):
    a = mol.GetAtomWithIdx(centre)
    if a.GetSymbol() == "S":
        return 92.0
    if any(mol.GetAtomWithIdx(n.GetIdx()).GetSymbol() == "S" and
           n.GetIdx() in ring for n in a.GetNeighbors()):
        return 111.5
    return 112.5


def ideal_angle_nonhyper(mol, c, i, j):
    a = mol.GetAtomWithIdx(c)
    n = a.GetDegree()
    h = hyb(a)
    if n == 2:
        if h == 1:
            return 180.0
        ring = None
        for r in mol.GetRingInfo().AtomRings():
            if len(r) == 5 and c in r and i in r and j in r:
                ring = r
        if ring is not None:
            return _interior_5(mol, c, ring)
        sym = a.GetSymbol()
        nb = [mol.GetAtomWithIdx(x) for x in (i, j)]
        if sym == "O":
            if any(x.GetSymbol() == "H" for x in nb):
                return 106.0
            if any(is_carbonyl_c(x) for x in nb):
                return 116.0
            if any(x.GetIsAromatic() for x in nb):
                return 118.0
            return 109.5
        if sym == "S":
            return 100.0
        return 120.0 if h == 2 else 109.5
    if n == 3:
        if h == 2:
            for r in mol.GetRingInfo().AtomRings():
                if len(r) == 5 and c in r:
                    inside = [x for x in (i, j) if x in r]
                    interior = _interior_5(mol, c, r)
                    if len(inside) == 2:
                        return interior
                    if len(inside) == 1:
                        return (360.0 - interior) / 2.0
            if is_carbonyl_c(a):
                bi = mol.GetBondBetweenAtoms(c, i).GetBondTypeAsDouble()
                bj = mol.GetBondBetweenAtoms(c, j).GetBondTypeAsDouble()
                return 114.0 if (bi == 1 and bj == 1) else 123.0
            return 120.0
        return 107.0 if a.GetSymbol() == "N" else 109.5
    if n == 4:
        return 109.47
    return 109.47


# --------------------------------------------------------------------------
# Full geometry audit
# --------------------------------------------------------------------------
def _angle(p, c, q):
    u, v = p - c, q - c
    cs = np.dot(u, v) / (np.linalg.norm(u) * np.linalg.norm(v) + 1e-12)
    return math.degrees(math.acos(float(np.clip(cs, -1, 1))))


def check_geometry(mol, X, tol_abs=0.10, tol_rel=0.06, ang_tol=15.0,
                   clash_factor=0.65, plane_tol=0.06, hyper_scale=1.0):
    """Audit coordinates X (N x 3, AddHs(SMILES) order) against the SMILES
    topology.  Returns a dict with every check and an overall verdict."""
    X = np.asarray(X, float)
    n = mol.GetNumAtoms()
    sym = [a.GetSymbol() for a in mol.GetAtoms()]
    dm = Chem.GetDistanceMatrix(mol)
    res = {"bonds": [], "angles": [], "hyper": [], "planarity": [],
           "clashes": [], "extra_bonds": [], "missing_bonds": []}

    # 1. bonds
    for b in mol.GetBonds():
        i, j = b.GetBeginAtomIdx(), b.GetEndAtomIdx()
        t, src = target_length(mol, b)
        d = float(np.linalg.norm(X[i] - X[j]))
        err = d - t
        ok = abs(err) <= max(tol_abs, tol_rel * t)
        res["bonds"].append(dict(i=i, j=j, ei=sym[i], ej=sym[j],
                                 order=b.GetBondTypeAsDouble(), target=t,
                                 source=src, dist=d, err=err, ok=ok))

    # 2. topology perceived from the coordinates
    bonded = {tuple(sorted((b.GetBeginAtomIdx(), b.GetEndAtomIdx())))
              for b in mol.GetBonds()}
    for i in range(n):
        for j in range(i + 1, n):
            d = np.linalg.norm(X[i] - X[j])
            near = d <= 1.25 * (cov(sym[i]) + cov(sym[j]))
            if near and (i, j) not in bonded and dm[i][j] > 2:
                res["extra_bonds"].append(dict(i=i, j=j, ei=sym[i], ej=sym[j],
                                               dist=float(d)))
            if (i, j) in bonded and d > 1.35 * (cov(sym[i]) + cov(sym[j])) \
                    + (0.3 if "I" in (sym[i], sym[j]) or "Xe" in (sym[i], sym[j]) else 0):
                res["missing_bonds"].append(dict(i=i, j=j, ei=sym[i],
                                                 ej=sym[j], dist=float(d)))

    # 3. angles
    hyper = set(hyper_centres(mol))
    for a in mol.GetAtoms():
        c = a.GetIdx()
        nb = [x.GetIdx() for x in a.GetNeighbors()]
        if len(nb) < 2:
            continue
        if c in hyper:
            info = classify_atom(a)
            T = template_angle_matrix(info["geometry"])
            k = len(nb)
            A = np.zeros((k, k))
            for p in range(k):
                for q in range(k):
                    if p != q:
                        A[p, q] = _angle(X[nb[p]], X[c], X[nb[q]])
            perms = np.array(list(itertools.permutations(range(T.shape[0]),
                                                         k)))
            Tp = T[perms[:, :, None], perms[:, None, :]]
            dev = np.abs(A[None] - Tp)
            dev[:, np.arange(k), np.arange(k)] = 0
            worst = dev.reshape(len(perms), -1).max(axis=1)
            best = int(np.argmin(worst))
            tol = SHAPE_TOL[info["geometry"]] * hyper_scale
            res["hyper"].append(dict(
                centre=c, element=sym[c], geometry=info["geometry"],
                ligands=nb, max_dev=float(worst[best]), tol=tol,
                min_angle=float(A[A > 0].min()) if k > 1 else 0.0,
                max_angle=float(A.max()), ok=bool(worst[best] <= tol)))
            continue
        for p in range(len(nb)):
            for q in range(p + 1, len(nb)):
                ideal = ideal_angle_nonhyper(mol, c, nb[p], nb[q])
                ang = _angle(X[nb[p]], X[c], X[nb[q]])
                # neighbours that are hypervalent centres bend more freely
                tol = ang_tol + (5.0 if (nb[p] in hyper or nb[q] in hyper)
                                 else 0.0)
                res["angles"].append(dict(
                    i=nb[p], c=c, j=nb[q], ec=sym[c], ideal=ideal, angle=ang,
                    err=ang - ideal, ok=abs(ang - ideal) <= tol))

    # 4. planarity: aromatic rings (+ substituents) and sp2 centres
    for ring in mol.GetRingInfo().AtomRings():
        if not all(mol.GetAtomWithIdx(x).GetIsAromatic() for x in ring):
            continue
        members = set(ring)
        for x in ring:
            for nb in mol.GetAtomWithIdx(x).GetNeighbors():
                members.add(nb.GetIdx())
        P = X[sorted(members)]
        P0 = P - P.mean(axis=0)
        normal = np.linalg.svd(P0)[2][-1]
        dev = float(np.abs(P0 @ normal).max())
        res["planarity"].append(dict(kind="aromatic ring", atoms=list(ring),
                                     max_dev=dev, ok=dev <= plane_tol * 1.5))
    for a in mol.GetAtoms():
        c = a.GetIdx()
        if c in hyper or a.GetDegree() != 3 or hyb(a) != 2:
            continue
        if a.GetSymbol() not in ("C", "N"):
            continue
        nb = [x.GetIdx() for x in a.GetNeighbors()]
        s = (_angle(X[nb[0]], X[c], X[nb[1]]) + _angle(X[nb[0]], X[c], X[nb[2]])
             + _angle(X[nb[1]], X[c], X[nb[2]]))
        res["planarity"].append(dict(kind="sp2 centre", atoms=[c],
                                     max_dev=360.0 - s, ok=(360.0 - s) <= 6.0))

    # 5. clashes (graph distance >= 3)
    for i in range(n):
        for j in range(i + 1, n):
            if dm[i][j] < 3:
                continue
            d = float(np.linalg.norm(X[i] - X[j]))
            lim = clash_factor * (vdw(sym[i]) + vdw(sym[j]))
            if d < lim:
                res["clashes"].append(dict(i=i, j=j, ei=sym[i], ej=sym[j],
                                           dist=d, limit=lim))

    # summary
    errs = [abs(r["err"]) for r in res["bonds"]]
    res["max_err"] = max(errs) if errs else 0.0
    res["mean_err"] = float(np.mean(errs)) if errs else 0.0
    res["rms_err"] = float(np.sqrt(np.mean(np.square(errs)))) if errs else 0.0
    res["bad_bonds"] = [r for r in res["bonds"] if not r["ok"]]
    res["bad_angles"] = [r for r in res["angles"] if not r["ok"]]
    res["bad_hyper"] = [r for r in res["hyper"] if not r["ok"]]
    res["bad_planar"] = [r for r in res["planarity"] if not r["ok"]]
    reasons = []
    if res["bad_bonds"]:
        reasons.append(f"{len(res['bad_bonds'])} bond(s) outside tolerance")
    if res["extra_bonds"]:
        reasons.append(f"{len(res['extra_bonds'])} unintended contact(s)")
    if res["missing_bonds"]:
        reasons.append(f"{len(res['missing_bonds'])} detached bond(s)")
    if res["bad_angles"]:
        reasons.append(f"{len(res['bad_angles'])} angle(s) outside tolerance")
    if res["bad_hyper"]:
        reasons.append(f"{len(res['bad_hyper'])} hypervalent shell(s) distorted")
    if res["bad_planar"]:
        reasons.append(f"{len(res['bad_planar'])} planarity violation(s)")
    if res["clashes"]:
        reasons.append(f"{len(res['clashes'])} steric clash(es)")
    res["reasons"] = reasons
    res["verdict"] = "PASS" if not reasons else "FAIL"
    return res

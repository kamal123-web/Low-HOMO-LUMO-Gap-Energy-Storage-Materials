# Low-HOMO-LUMO-Gap Energy Storage Materials: in-memory RDKit–ASE–PySCF screening with SMILES-authoritative geometry validation

Code and data for the article *A Unified In-Memory Python Framework with SMILES-Authoritative Geometry Validation for High-Throughput DFT Screening of HOMO–LUMO Gaps, Including Hypervalent –SF₅ Chemistry* (Journal of Molecular Modeling).

* Author: Kamalraj Devaraj (ORCID 0000-0002-0790-2619)
* Archived release (frozen): Zenodo DOI **10.5281/zenodo.24189301** 
* Licences: code MIT (`LICENSE`); data and documents CC BY 4.0 (`LICENSE-DATA.md`)

## What is in this repository

| Path | Content |
|---|---|
| `HLMO_Screening_Notebook.ipynb` | Colab/Jupyter driver: library generation, in-memory transfer, optimization, validation gate, B3LYP calculations, ML |
| `src/` | `geom_common.py`, `g3_engine.py`, `geometry_gate.py`, `validate_geometry.py` (validator, repair engine, GUI/CLI) |
| `data/` | `virtual_library_50.csv` (the 50 evaluated molecules), `quantum_ground_truth_50.csv` |
| `results/` | `All_results.jsonl` (**final results used in the paper**), the pre-correction file and the log of the STO-3G recomputation (see below) |
| `analysis/` | `ml_analysis.py` (Ridge/RF, baselines, grouped CV), `make_figures.py`, `rerun_five_sto3g.py` |
| `si/` | Validation reports, bond tables, repaired coordinates and code from the Supporting Information |
| `docs/User_manual.docx` | Step-by-step manual (setup, running, errors) |
| `tests/smoke_test.py` | Integrity and reproducibility checks (about 1 minute, no DFT) |

## Quick start

```bash
git clone https://github.com/kamal123-web/Low-HOMO-LUMO-Gap-Energy-Storage-Materials.git
cd Low-HOMO-LUMO-Gap-Energy-Storage-Materials
pip install -r requirements.txt
python tests/smoke_test.py          # checks the results file, the ML numbers and the validator
python analysis/ml_analysis.py      # regenerates the ML statistics in the paper
```

To rerun the screening, open `HLMO_Screening_Notebook.ipynb` (Colab recommended), upload the four files from `src/`
and `data/virtual_library_50.csv` (copy it to `research_data/unique_virtual_library.csv`), and run the cells in order.
Do not run the pre-seed cell on a new library (it rewrites the results file). A full 50-molecule run takes many hours on a
cloud CPU. Validate any geometry on its own with
`python src/validate_geometry.py --smiles "FS(F)(F)(F)(F)c1ccccc1" --after geometry.xyz --plot`
or rebuild one with `python src/g3_engine.py "SMILES" prefix`.

## Computational protocol (summary)

B3LYP in PySCF; STO-3G for the 48 standard molecules (LANL2DZ ECP on iodine); 6-31G(d) for the two –SF₅ molecules
(MOL_0007, MOL_0035); neutral closed-shell species only. Every optimized geometry passes a SMILES-authoritative
validation gate; failures are rebuilt by the G3 engine (distance geometry plus restrained L-BFGS, template geometry,
not DFT-relaxed). Limitations are discussed in Section 6 of the paper.

## Note on the data correction

An earlier internal run evaluated the five rebuilt non-hypervalent molecules (MOL_0020, 0021, 0037, 0048, 0049) at
6-31G(d) while labelling them STO-3G. They were recomputed at B3LYP/STO-3G on the same rebuilt geometries
(`analysis/rerun_five_sto3g.py`; the 6-31G(d) energies of the script's verification step reproduce the earlier values).
`results/All_results.jsonl` contains the corrected values and the notebook driver contains the fix
(`_qc_with_basis`); `results/All_results_before_basis_correction.jsonl` is kept for transparency only.

## How to cite

See `CITATION.cff` (GitHub shows a "Cite this repository" button) and cite the article and the Zenodo archive.

## Releasing on Zenodo (maintainer notes)

1. Create the GitHub repository (public) and upload this folder.
2. In Zenodo, link your GitHub account and enable the repository; then create a GitHub **release** (tag `v1.0.0`).
3. Zenodo archives the release and mints a DOI. Insert it in `CITATION.cff`, this README and the manuscript's Code Availability statement, and
   cite the *version* DOI for the exact archive used in the paper.

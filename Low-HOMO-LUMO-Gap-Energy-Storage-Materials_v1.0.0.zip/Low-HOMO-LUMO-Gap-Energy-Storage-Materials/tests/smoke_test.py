#!/usr/bin/env python3
"""Smoke test (about 1 minute, no DFT). Run from the repository root:  python tests/smoke_test.py"""
import json, os, sys, tempfile
import numpy as np
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))

# 1. results file integrity
R = [json.loads(l) for l in open(os.path.join(ROOT, "results", "All_results.jsonl")) if l.strip()]
assert len(R) == 50 and all(r["Status"] == "SUCCESS" for r in R), "expected 50 SUCCESS records"
assert all(r["Geometry_Validation"] == "PASS" for r in R), "all geometries must pass the gate"
fix = {r["Molecule_ID"]: r for r in R if r.get("Basis_Electronic") == "sto-3g"}
assert sorted(fix) == ["MOL_0020", "MOL_0021", "MOL_0037", "MOL_0048", "MOL_0049"], fix.keys()
for r in R:
    assert abs((r["LUMO_eV"] - r["HOMO_eV"]) - r["HOMO_LUMO_Gap_eV"]) < 1e-6, r["Molecule_ID"]
print("results file OK (50 records; 5 rebuilt molecules at STO-3G)")

# 2. machine-learning numbers quoted in the manuscript
from rdkit import Chem
from rdkit.Chem import rdFingerprintGenerator as G
from sklearn.linear_model import Ridge
from sklearn.model_selection import KFold, cross_val_predict
from sklearn.metrics import r2_score, mean_absolute_error as mae
R.sort(key=lambda r: r["Molecule_ID"])
g = G.GetMorganGenerator(radius=2, fpSize=2048)
X = np.array([g.GetCountFingerprintAsNumPy(Chem.MolFromSmiles(r["SMILES"])) for r in R], float)
y = np.array([r["HOMO_LUMO_Gap_eV"] for r in R])
p = cross_val_predict(Ridge(alpha=0.1), X, y, cv=KFold(5, shuffle=True, random_state=42))
print(f"Ridge CV R2 = {r2_score(y,p):.4f}  MAE = {mae(y,p):.4f}  (manuscript: 0.8217 / 0.3157)")
assert abs(r2_score(y, p) - 0.8217) < 0.002 and abs(mae(y, p) - 0.3157) < 0.002

# 3. validator + repair engine on a hypervalent molecule
from geometry_gate import validate_and_repair
import g3_engine
with tempfile.TemporaryDirectory() as d:
    smi = "FS(F)(F)(F)(F)c1ccccc1"
    g3_engine.repair_structure(smiles=smi, input_xyz=None, output_xyz=f"{d}/m.xyz", output_sdf=f"{d}/m.sdf",
                               output_png=f"{d}/m.png", output_report=f"{d}/m.txt")
    gate = validate_and_repair("TEST", smi, f"{d}/m.xyz", d, verbose=False)
    print("gate on rebuilt PhSF5:", gate["action"], gate["status"])
    assert gate["status"] == "PASS"
print("ALL CHECKS PASSED")
